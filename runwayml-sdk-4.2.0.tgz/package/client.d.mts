import type { RequestInit, RequestInfo } from "./internal/builtin-types.mjs";
import type { PromiseOrValue, MergedRequestInit, FinalizedRequestInit } from "./internal/types.mjs";
export type { Logger, LogLevel } from "./internal/utils/log.mjs";
import * as Opts from "./internal/request-options.mjs";
import * as Errors from "./core/error.mjs";
import * as Pagination from "./core/pagination.mjs";
import { type CursorPageParams, CursorPageResponse } from "./core/pagination.mjs";
import * as UploadsCore from "./core/uploads.mjs";
import * as API from "./resources/index.mjs";
import { APIPromise } from "./core/api-promise.mjs";
import { AvatarConversationListParams, AvatarConversationListResponse, AvatarConversationListResponsesCursorPage, AvatarConversationRetrieveResponse, AvatarConversations } from "./resources/avatar-conversations.mjs";
import { AvatarVideoCreateParams, AvatarVideoCreateResponse, AvatarVideos } from "./resources/avatar-videos.mjs";
import { AvatarCreateParams, AvatarCreateResponse, AvatarGetUsageParams, AvatarGetUsageResponse, AvatarListParams, AvatarListResponse, AvatarListResponsesCursorPage, AvatarRetrieveResponse, AvatarUpdateParams, AvatarUpdateResponse, Avatars } from "./resources/avatars.mjs";
import { CharacterPerformance, CharacterPerformanceCreateParams, CharacterPerformanceCreateResponse } from "./resources/character-performance.mjs";
import { DocumentCreateParams, DocumentCreateResponse, DocumentListParams, DocumentListResponse, DocumentListResponsesCursorPage, DocumentRetrieveResponse, DocumentUpdateParams, Documents } from "./resources/documents.mjs";
import { ImageToVideo, ImageToVideoCreateParams, ImageToVideoCreateResponse } from "./resources/image-to-video.mjs";
import { ImageUpscale, ImageUpscaleCreateParams, ImageUpscaleCreateResponse } from "./resources/image-upscale.mjs";
import { Organization, OrganizationRetrieveResponse, OrganizationRetrieveUsageParams, OrganizationRetrieveUsageResponse } from "./resources/organization.mjs";
import { RealtimeSessionCreateParams, RealtimeSessionCreateResponse, RealtimeSessionRetrieveResponse, RealtimeSessions } from "./resources/realtime-sessions.mjs";
import { RecipeMarketingStockImageParams, RecipeMarketingStockImageResponse, RecipeMultiShotVideoParams, RecipeMultiShotVideoResponse, RecipeProductAdParams, RecipeProductAdResponse, RecipeProductCampaignImageParams, RecipeProductCampaignImageResponse, RecipeProductSwapParams, RecipeProductSwapResponse, RecipeProductUgcParams, RecipeProductUgcResponse, Recipes } from "./resources/recipes.mjs";
import { SoundEffect, SoundEffectCreateParams, SoundEffectCreateResponse } from "./resources/sound-effect.mjs";
import { SpeechToSpeech, SpeechToSpeechCreateParams, SpeechToSpeechCreateResponse } from "./resources/speech-to-speech.mjs";
import { TaskRetrieveResponse, Tasks } from "./resources/tasks.mjs";
import { TextToImage, TextToImageCreateParams, TextToImageCreateResponse } from "./resources/text-to-image.mjs";
import { TextToSpeech, TextToSpeechCreateParams, TextToSpeechCreateResponse } from "./resources/text-to-speech.mjs";
import { TextToVideo, TextToVideoCreateParams, TextToVideoCreateResponse } from "./resources/text-to-video.mjs";
import { VideoToVideo, VideoToVideoCreateParams, VideoToVideoCreateResponse } from "./resources/video-to-video.mjs";
import { VoiceDubbing, VoiceDubbingCreateParams, VoiceDubbingCreateResponse } from "./resources/voice-dubbing.mjs";
import { VoiceIsolation, VoiceIsolationCreateParams, VoiceIsolationCreateResponse } from "./resources/voice-isolation.mjs";
import { Uploads, UploadsCreateEphemeralParams, UploadCreateEphemeralResponse } from "./resources/uploads.mjs";
import { VoiceCreateParams, VoiceCreateResponse, VoiceListParams, VoiceListResponse, VoiceListResponsesCursorPage, VoicePreviewParams, VoicePreviewResponse, VoiceRetrieveResponse, VoiceUpdateParams, VoiceUpdateResponse, Voices } from "./resources/voices.mjs";
import { WorkflowInvocationRetrieveResponse, WorkflowInvocations } from "./resources/workflow-invocations.mjs";
import { WorkflowListResponse, WorkflowRetrieveResponse, WorkflowRunParams, WorkflowRunResponse, Workflows } from "./resources/workflows.mjs";
import { type Fetch } from "./internal/builtin-types.mjs";
import { HeadersLike, NullableHeaders } from "./internal/headers.mjs";
import { FinalRequestOptions, RequestOptions } from "./internal/request-options.mjs";
import { type LogLevel, type Logger } from "./internal/utils/log.mjs";
export interface ClientOptions {
    /**
     * Defaults to process.env['RUNWAYML_API_SECRET'].
     */
    apiKey?: string | undefined;
    runwayVersion?: string | undefined;
    /**
     * Override the default base URL for the API, e.g., "https://api.example.com/v2/"
     *
     * Defaults to process.env['RUNWAYML_BASE_URL'].
     */
    baseURL?: string | null | undefined;
    /**
     * The maximum amount of time (in milliseconds) that the client should wait for a response
     * from the server before timing out a single request.
     *
     * Note that request timeouts are retried by default, so in a worst-case scenario you may wait
     * much longer than this timeout before the promise succeeds or fails.
     *
     * @unit milliseconds
     */
    timeout?: number | undefined;
    /**
     * Additional `RequestInit` options to be passed to `fetch` calls.
     * Properties will be overridden by per-request `fetchOptions`.
     */
    fetchOptions?: MergedRequestInit | undefined;
    /**
     * Specify a custom `fetch` function implementation.
     *
     * If not provided, we expect that `fetch` is defined globally.
     */
    fetch?: Fetch | undefined;
    /**
     * The maximum number of times that the client will retry a request in case of a
     * temporary failure, like a network error or a 5XX error from the server.
     *
     * @default 2
     */
    maxRetries?: number | undefined;
    /**
     * Default headers to include with every request to the API.
     *
     * These can be removed in individual requests by explicitly setting the
     * header to `null` in request options.
     */
    defaultHeaders?: HeadersLike | undefined;
    /**
     * Default query parameters to include with every request to the API.
     *
     * These can be removed in individual requests by explicitly setting the
     * param to `undefined` in request options.
     */
    defaultQuery?: Record<string, string | undefined> | undefined;
    /**
     * Set the log level.
     *
     * Defaults to process.env['RUNWAYML_LOG'] or 'warn' if it isn't set.
     */
    logLevel?: LogLevel | undefined;
    /**
     * Set the logger.
     *
     * Defaults to globalThis.console.
     */
    logger?: Logger | undefined;
}
/**
 * API Client for interfacing with the RunwayML API.
 */
export declare class RunwayML {
    #private;
    apiKey: string;
    runwayVersion: string;
    baseURL: string;
    maxRetries: number;
    timeout: number;
    logger: Logger;
    logLevel: LogLevel | undefined;
    fetchOptions: MergedRequestInit | undefined;
    private fetch;
    protected idempotencyHeader?: string;
    private _options;
    /**
     * API Client for interfacing with the RunwayML API.
     *
     * @param {string | undefined} [opts.apiKey=process.env['RUNWAYML_API_SECRET'] ?? undefined]
     * @param {string | undefined} [opts.runwayVersion=2024-11-06]
     * @param {string} [opts.baseURL=process.env['RUNWAYML_BASE_URL'] ?? https://api.dev.runwayml.com] - Override the default base URL for the API.
     * @param {number} [opts.timeout=1 minute] - The maximum amount of time (in milliseconds) the client will wait for a response before timing out.
     * @param {MergedRequestInit} [opts.fetchOptions] - Additional `RequestInit` options to be passed to `fetch` calls.
     * @param {Fetch} [opts.fetch] - Specify a custom `fetch` function implementation.
     * @param {number} [opts.maxRetries=2] - The maximum number of times the client will retry a request.
     * @param {HeadersLike} opts.defaultHeaders - Default headers to include with every request to the API.
     * @param {Record<string, string | undefined>} opts.defaultQuery - Default query parameters to include with every request to the API.
     */
    constructor({ baseURL, apiKey, runwayVersion, ...opts }?: ClientOptions);
    /**
     * Create a new client instance re-using the same options given to the current client with optional overriding.
     */
    withOptions(options: Partial<ClientOptions>): this;
    protected defaultQuery(): Record<string, string | undefined> | undefined;
    protected validateHeaders({ values, nulls }: NullableHeaders): void;
    protected authHeaders(opts: FinalRequestOptions): Promise<NullableHeaders | undefined>;
    /**
     * Basic re-implementation of `qs.stringify` for primitive types.
     */
    protected stringifyQuery(query: object | Record<string, unknown>): string;
    private getUserAgent;
    protected defaultIdempotencyKey(): string;
    protected makeStatusError(status: number, error: Object, message: string | undefined, headers: Headers): Errors.APIError;
    buildURL(path: string, query: Record<string, unknown> | null | undefined, defaultBaseURL?: string | undefined): string;
    /**
     * Used as a callback for mutating the given `FinalRequestOptions` object.
     */
    protected prepareOptions(options: FinalRequestOptions): Promise<void>;
    /**
     * Used as a callback for mutating the given `RequestInit` object.
     *
     * This is useful for cases where you want to add certain headers based off of
     * the request properties, e.g. `method` or `url`.
     */
    protected prepareRequest(request: RequestInit, { url, options }: {
        url: string;
        options: FinalRequestOptions;
    }): Promise<void>;
    get<Rsp>(path: string, opts?: PromiseOrValue<RequestOptions>): APIPromise<Rsp>;
    post<Rsp>(path: string, opts?: PromiseOrValue<RequestOptions>): APIPromise<Rsp>;
    patch<Rsp>(path: string, opts?: PromiseOrValue<RequestOptions>): APIPromise<Rsp>;
    put<Rsp>(path: string, opts?: PromiseOrValue<RequestOptions>): APIPromise<Rsp>;
    delete<Rsp>(path: string, opts?: PromiseOrValue<RequestOptions>): APIPromise<Rsp>;
    private methodRequest;
    request<Rsp>(options: PromiseOrValue<FinalRequestOptions>, remainingRetries?: number | null): APIPromise<Rsp>;
    private makeRequest;
    getAPIList<Item, PageClass extends Pagination.AbstractPage<Item> = Pagination.AbstractPage<Item>>(path: string, Page: new (...args: any[]) => PageClass, opts?: PromiseOrValue<RequestOptions>): Pagination.PagePromise<PageClass, Item>;
    requestAPIList<Item = unknown, PageClass extends Pagination.AbstractPage<Item> = Pagination.AbstractPage<Item>>(Page: new (...args: ConstructorParameters<typeof Pagination.AbstractPage>) => PageClass, options: PromiseOrValue<FinalRequestOptions>): Pagination.PagePromise<PageClass, Item>;
    fetchWithTimeout(url: RequestInfo, init: RequestInit | undefined, ms: number, controller: AbortController): Promise<Response>;
    private shouldRetry;
    private retryRequest;
    private calculateDefaultRetryTimeoutMillis;
    buildRequest(inputOptions: FinalRequestOptions, { retryCount }?: {
        retryCount?: number;
    }): Promise<{
        req: FinalizedRequestInit;
        url: string;
        timeout: number;
    }>;
    private buildHeaders;
    private _makeAbort;
    private buildBody;
    static RunwayML: typeof RunwayML;
    static DEFAULT_TIMEOUT: number;
    static RunwayMLError: typeof Errors.RunwayMLError;
    static APIError: typeof Errors.APIError;
    static APIConnectionError: typeof Errors.APIConnectionError;
    static APIConnectionTimeoutError: typeof Errors.APIConnectionTimeoutError;
    static APIUserAbortError: typeof Errors.APIUserAbortError;
    static NotFoundError: typeof Errors.NotFoundError;
    static ConflictError: typeof Errors.ConflictError;
    static RateLimitError: typeof Errors.RateLimitError;
    static BadRequestError: typeof Errors.BadRequestError;
    static AuthenticationError: typeof Errors.AuthenticationError;
    static InternalServerError: typeof Errors.InternalServerError;
    static PermissionDeniedError: typeof Errors.PermissionDeniedError;
    static UnprocessableEntityError: typeof Errors.UnprocessableEntityError;
    static toFile: typeof UploadsCore.toFile;
    /**
     * Endpoints for managing tasks that have been submitted.
     */
    tasks: API.Tasks;
    /**
     * These endpoints all kick off tasks to create generations.
     */
    imageToVideo: API.ImageToVideo;
    /**
     * These endpoints all kick off tasks to create generations.
     */
    videoToVideo: API.VideoToVideo;
    /**
     * These endpoints all kick off tasks to create generations.
     */
    textToVideo: API.TextToVideo;
    /**
     * These endpoints all kick off tasks to create generations.
     */
    textToImage: API.TextToImage;
    /**
     * These endpoints all kick off tasks to create generations.
     */
    characterPerformance: API.CharacterPerformance;
    /**
     * These endpoints all kick off tasks to create generations.
     */
    textToSpeech: API.TextToSpeech;
    /**
     * These endpoints all kick off tasks to create generations.
     */
    soundEffect: API.SoundEffect;
    /**
     * These endpoints all kick off tasks to create generations.
     */
    voiceIsolation: API.VoiceIsolation;
    /**
     * These endpoints all kick off tasks to create generations.
     */
    voiceDubbing: API.VoiceDubbing;
    /**
     * These endpoints all kick off tasks to create generations.
     */
    speechToSpeech: API.SpeechToSpeech;
    /**
     * These endpoints all kick off tasks to create generations.
     */
    imageUpscale: API.ImageUpscale;
    organization: API.Organization;
    avatars: API.Avatars;
    avatarConversations: API.AvatarConversations;
    avatarVideos: API.AvatarVideos;
    documents: API.Documents;
    realtimeSessions: API.RealtimeSessions;
    recipes: API.Recipes;
    voices: API.Voices;
    uploads: API.Uploads;
    workflows: API.Workflows;
    workflowInvocations: API.WorkflowInvocations;
}
export declare namespace RunwayML {
    export type RequestOptions = Opts.RequestOptions;
    export import CursorPage = Pagination.CursorPage;
    export { type CursorPageParams as CursorPageParams, type CursorPageResponse as CursorPageResponse };
    export { Tasks as Tasks, type TaskRetrieveResponse as TaskRetrieveResponse };
    export { ImageToVideo as ImageToVideo, type ImageToVideoCreateResponse as ImageToVideoCreateResponse, type ImageToVideoCreateParams as ImageToVideoCreateParams, };
    export { VideoToVideo as VideoToVideo, type VideoToVideoCreateResponse as VideoToVideoCreateResponse, type VideoToVideoCreateParams as VideoToVideoCreateParams, };
    export { TextToVideo as TextToVideo, type TextToVideoCreateResponse as TextToVideoCreateResponse, type TextToVideoCreateParams as TextToVideoCreateParams, };
    export { TextToImage as TextToImage, type TextToImageCreateResponse as TextToImageCreateResponse, type TextToImageCreateParams as TextToImageCreateParams, };
    export { CharacterPerformance as CharacterPerformance, type CharacterPerformanceCreateResponse as CharacterPerformanceCreateResponse, type CharacterPerformanceCreateParams as CharacterPerformanceCreateParams, };
    export { TextToSpeech as TextToSpeech, type TextToSpeechCreateResponse as TextToSpeechCreateResponse, type TextToSpeechCreateParams as TextToSpeechCreateParams, };
    export { SoundEffect as SoundEffect, type SoundEffectCreateResponse as SoundEffectCreateResponse, type SoundEffectCreateParams as SoundEffectCreateParams, };
    export { VoiceIsolation as VoiceIsolation, type VoiceIsolationCreateResponse as VoiceIsolationCreateResponse, type VoiceIsolationCreateParams as VoiceIsolationCreateParams, };
    export { VoiceDubbing as VoiceDubbing, type VoiceDubbingCreateResponse as VoiceDubbingCreateResponse, type VoiceDubbingCreateParams as VoiceDubbingCreateParams, };
    export { SpeechToSpeech as SpeechToSpeech, type SpeechToSpeechCreateResponse as SpeechToSpeechCreateResponse, type SpeechToSpeechCreateParams as SpeechToSpeechCreateParams, };
    export { ImageUpscale as ImageUpscale, type ImageUpscaleCreateResponse as ImageUpscaleCreateResponse, type ImageUpscaleCreateParams as ImageUpscaleCreateParams, };
    export { Organization as Organization, type OrganizationRetrieveResponse as OrganizationRetrieveResponse, type OrganizationRetrieveUsageResponse as OrganizationRetrieveUsageResponse, type OrganizationRetrieveUsageParams as OrganizationRetrieveUsageParams, };
    export { Avatars as Avatars, type AvatarCreateResponse as AvatarCreateResponse, type AvatarRetrieveResponse as AvatarRetrieveResponse, type AvatarUpdateResponse as AvatarUpdateResponse, type AvatarListResponse as AvatarListResponse, type AvatarGetUsageResponse as AvatarGetUsageResponse, type AvatarListResponsesCursorPage as AvatarListResponsesCursorPage, type AvatarCreateParams as AvatarCreateParams, type AvatarUpdateParams as AvatarUpdateParams, type AvatarListParams as AvatarListParams, type AvatarGetUsageParams as AvatarGetUsageParams, };
    export { AvatarConversations as AvatarConversations, type AvatarConversationRetrieveResponse as AvatarConversationRetrieveResponse, type AvatarConversationListResponse as AvatarConversationListResponse, type AvatarConversationListResponsesCursorPage as AvatarConversationListResponsesCursorPage, type AvatarConversationListParams as AvatarConversationListParams, };
    export { AvatarVideos as AvatarVideos, type AvatarVideoCreateResponse as AvatarVideoCreateResponse, type AvatarVideoCreateParams as AvatarVideoCreateParams, };
    export { Documents as Documents, type DocumentCreateResponse as DocumentCreateResponse, type DocumentRetrieveResponse as DocumentRetrieveResponse, type DocumentListResponse as DocumentListResponse, type DocumentListResponsesCursorPage as DocumentListResponsesCursorPage, type DocumentCreateParams as DocumentCreateParams, type DocumentUpdateParams as DocumentUpdateParams, type DocumentListParams as DocumentListParams, };
    export { RealtimeSessions as RealtimeSessions, type RealtimeSessionCreateResponse as RealtimeSessionCreateResponse, type RealtimeSessionRetrieveResponse as RealtimeSessionRetrieveResponse, type RealtimeSessionCreateParams as RealtimeSessionCreateParams, };
    export { Recipes as Recipes, type RecipeMarketingStockImageResponse as RecipeMarketingStockImageResponse, type RecipeMultiShotVideoResponse as RecipeMultiShotVideoResponse, type RecipeProductAdResponse as RecipeProductAdResponse, type RecipeProductCampaignImageResponse as RecipeProductCampaignImageResponse, type RecipeProductSwapResponse as RecipeProductSwapResponse, type RecipeProductUgcResponse as RecipeProductUgcResponse, type RecipeMarketingStockImageParams as RecipeMarketingStockImageParams, type RecipeMultiShotVideoParams as RecipeMultiShotVideoParams, type RecipeProductAdParams as RecipeProductAdParams, type RecipeProductCampaignImageParams as RecipeProductCampaignImageParams, type RecipeProductSwapParams as RecipeProductSwapParams, type RecipeProductUgcParams as RecipeProductUgcParams, };
    export { Voices as Voices, type VoiceCreateResponse as VoiceCreateResponse, type VoiceRetrieveResponse as VoiceRetrieveResponse, type VoiceUpdateResponse as VoiceUpdateResponse, type VoiceListResponse as VoiceListResponse, type VoicePreviewResponse as VoicePreviewResponse, type VoiceListResponsesCursorPage as VoiceListResponsesCursorPage, type VoiceCreateParams as VoiceCreateParams, type VoiceUpdateParams as VoiceUpdateParams, type VoiceListParams as VoiceListParams, type VoicePreviewParams as VoicePreviewParams, };
    export { Uploads as Uploads, type UploadCreateEphemeralResponse as UploadCreateEphemeralResponse, type UploadsCreateEphemeralParams as UploadsCreateEphemeralParams, };
    export { Workflows as Workflows, type WorkflowRetrieveResponse as WorkflowRetrieveResponse, type WorkflowListResponse as WorkflowListResponse, type WorkflowRunResponse as WorkflowRunResponse, type WorkflowRunParams as WorkflowRunParams, };
    export { WorkflowInvocations as WorkflowInvocations, type WorkflowInvocationRetrieveResponse as WorkflowInvocationRetrieveResponse, };
}
//# sourceMappingURL=client.d.mts.map