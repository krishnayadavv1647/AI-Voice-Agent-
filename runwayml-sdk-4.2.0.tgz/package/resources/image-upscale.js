"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.ImageUpscale = void 0;
const resource_1 = require("../core/resource.js");
const polling_1 = require("../lib/polling.js");
/**
 * These endpoints all kick off tasks to create generations.
 */
class ImageUpscale extends resource_1.APIResource {
    /**
     * Upscale an image with Magnific precision upscaling. Each input dimension must be
     * between 300px and 8000px. Output width and height are the input dimensions
     * multiplied by `scaleFactor` (default 2). Output width times height cannot exceed
     * 25,300,000 pixels (~25.3 million).
     *
     * @example
     * ```ts
     * const imageUpscale = await client.imageUpscale.create({
     *   imageUri: 'https://example.com/image.jpg',
     *   model: 'magnific_precision_upscaler_v2',
     * });
     * ```
     */
    create(body, options) {
        return (0, polling_1.wrapAsWaitableResource)(this._client)(this._client.post('/v1/image_upscale', { body, ...options }));
    }
}
exports.ImageUpscale = ImageUpscale;
//# sourceMappingURL=image-upscale.js.map