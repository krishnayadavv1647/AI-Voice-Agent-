"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.AvatarConversations = void 0;
const resource_1 = require("../core/resource.js");
const pagination_1 = require("../core/pagination.js");
const headers_1 = require("../internal/headers.js");
const path_1 = require("../internal/utils/path.js");
class AvatarConversations extends resource_1.APIResource {
    /**
     * Get detailed information about a specific conversation, including the transcript
     * and recording download URL when available. The conversation ID is the same value
     * returned when the realtime session was created.
     */
    retrieve(id, options) {
        return this._client.get((0, path_1.path) `/v1/avatar_conversations/${id}`, options);
    }
    /**
     * List realtime avatar conversations for the authenticated user with cursor-based
     * pagination. Each conversation corresponds to a realtime session, and the
     * conversation ID matches the realtime session ID. Pass `avatar` to restrict
     * results to a single avatar.
     */
    list(query, options) {
        return this._client.getAPIList('/v1/avatar_conversations', (pagination_1.CursorPage), {
            query,
            ...options,
        });
    }
    /**
     * Delete a conversation and its associated data.
     */
    delete(id, options) {
        return this._client.delete((0, path_1.path) `/v1/avatar_conversations/${id}`, {
            ...options,
            headers: (0, headers_1.buildHeaders)([{ Accept: '*/*' }, options?.headers]),
        });
    }
}
exports.AvatarConversations = AvatarConversations;
//# sourceMappingURL=avatar-conversations.js.map