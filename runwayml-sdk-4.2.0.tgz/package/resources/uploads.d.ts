import { APIResource } from "../core/resource.js";
import { RequestOptions } from "../internal/request-options.js";
import { Uploadable } from "../internal/uploads.js";
export declare class Uploads extends APIResource {
    /**
     * Uploads a temporary media file that can be used in other API generation
     * requests.
     *
     * The uploaded files will be automatically expired and deleted after a
     * period of time.
     */
    createEphemeral(params: UploadsCreateEphemeralParams, options?: RequestOptions): Promise<UploadCreateEphemeralResponse>;
}
export interface UploadCreateEphemeralResponse {
    /**
     * The Runway upload URI to use in other API generation requests.
     */
    uri: string;
}
export interface UploadsCreateEphemeralParams {
    /**
     * The file to upload. Must be a supported media type (image, video, or audio).
     */
    file: Uploadable;
    /**
     * Optional metadata for the file, serialized as a field in multipart/form-data.
     */
    fileMetadata?: string;
}
export declare namespace Uploads {
    export { type UploadCreateEphemeralResponse as UploadCreateEphemeralResponse, type UploadsCreateEphemeralParams as UploadsCreateEphemeralParams, };
}
//# sourceMappingURL=uploads.d.ts.map