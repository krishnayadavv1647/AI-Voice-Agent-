// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../core/resource.mjs";
import { path } from "../internal/utils/path.mjs";
export class Workflows extends APIResource {
    /**
     * Returns details about a specific published workflow, including its graph schema.
     */
    retrieve(id, options) {
        return this._client.get(path `/v1/workflows/${id}`, options);
    }
    /**
     * Returns a list of all published workflows for the authenticated user, grouped by
     * source workflow with their published versions.
     */
    list(options) {
        return this._client.get('/v1/workflows', options);
    }
    /**
     * Start a new task to execute a published workflow. You can optionally provide
     * custom input values via `nodeOutputs` to override the defaults defined in the
     * workflow graph.
     */
    run(id, body = {}, options) {
        return this._client.post(path `/v1/workflows/${id}`, { body, ...options });
    }
}
//# sourceMappingURL=workflows.mjs.map