"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.Workflows = void 0;
const resource_1 = require("../core/resource.js");
const path_1 = require("../internal/utils/path.js");
class Workflows extends resource_1.APIResource {
    /**
     * Returns details about a specific published workflow, including its graph schema.
     */
    retrieve(id, options) {
        return this._client.get((0, path_1.path) `/v1/workflows/${id}`, options);
    }
    /**
     * Returns a list of all published workflows for the authenticated user, grouped by
     * source workflow with their published versions.
     */
    list(options) {
        return this._client.get('/v1/workflows', options);
    }
    /**
     * Start a new task to execute a published workflow. You can optionally provide
     * custom input values via `nodeOutputs` to override the defaults defined in the
     * workflow graph.
     */
    run(id, body = {}, options) {
        return this._client.post((0, path_1.path) `/v1/workflows/${id}`, { body, ...options });
    }
}
exports.Workflows = Workflows;
//# sourceMappingURL=workflows.js.map