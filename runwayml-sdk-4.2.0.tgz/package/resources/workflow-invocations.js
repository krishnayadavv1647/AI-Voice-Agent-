"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.WorkflowInvocations = void 0;
const resource_1 = require("../core/resource.js");
const path_1 = require("../internal/utils/path.js");
const polling_1 = require("../lib/polling.js");
class WorkflowInvocations extends resource_1.APIResource {
    /**
     * Return details about a workflow invocation. Consumers of this API should not
     * expect updates more frequent than once every five seconds for a given workflow
     * invocation.
     */
    retrieve(id, options) {
        return (0, polling_1.wrapAsWaitableWorkflowInvocation)(this._client)(this._client.get((0, path_1.path) `/v1/workflow_invocations/${id}`, options), true);
    }
}
exports.WorkflowInvocations = WorkflowInvocations;
//# sourceMappingURL=workflow-invocations.js.map