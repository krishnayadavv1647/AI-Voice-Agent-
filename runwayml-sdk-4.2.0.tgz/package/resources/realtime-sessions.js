"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.RealtimeSessions = void 0;
const resource_1 = require("../core/resource.js");
const headers_1 = require("../internal/headers.js");
const path_1 = require("../internal/utils/path.js");
class RealtimeSessions extends resource_1.APIResource {
    /**
     * Create a new realtime session with the specified model configuration. The
     * returned ID is also the conversation ID used later to fetch transcripts and
     * recordings from the avatar conversation endpoints.
     */
    create(body, options) {
        return this._client.post('/v1/realtime_sessions', { body, ...options });
    }
    /**
     * Get the status of a realtime session. This endpoint uses the same ID that the
     * avatar conversation endpoints later expose as the conversation ID.
     */
    retrieve(id, options) {
        return this._client.get((0, path_1.path) `/v1/realtime_sessions/${id}`, options);
    }
    /**
     * Cancel an active realtime session.
     */
    delete(id, options) {
        return this._client.delete((0, path_1.path) `/v1/realtime_sessions/${id}`, {
            ...options,
            headers: (0, headers_1.buildHeaders)([{ Accept: '*/*' }, options?.headers]),
        });
    }
}
exports.RealtimeSessions = RealtimeSessions;
//# sourceMappingURL=realtime-sessions.js.map