"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.Avatars = void 0;
const resource_1 = require("../core/resource.js");
const pagination_1 = require("../core/pagination.js");
const headers_1 = require("../internal/headers.js");
const path_1 = require("../internal/utils/path.js");
class Avatars extends resource_1.APIResource {
    /**
     * Create a new avatar with a reference image and voice.
     *
     * @example
     * ```ts
     * const avatar = await client.avatars.create({
     *   name: 'x',
     *   personality:
     *     'You are a helpful support agent assisting users with their account questions. Be friendly, patient, and provide clear step-by-step guidance.',
     *   referenceImage: 'https://example.com/reference.jpg',
     *   voice: { presetId: 'adrian', type: 'runway-live-preset' },
     * });
     * ```
     */
    create(body, options) {
        return this._client.post('/v1/avatars', { body, ...options });
    }
    /**
     * Get details of a specific avatar.
     *
     * @example
     * ```ts
     * const avatar = await client.avatars.retrieve(
     *   '182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e',
     * );
     * ```
     */
    retrieve(id, options) {
        return this._client.get((0, path_1.path) `/v1/avatars/${id}`, options);
    }
    /**
     * Update an existing avatar. At least one field must be provided.
     *
     * @example
     * ```ts
     * const avatar = await client.avatars.update(
     *   '182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e',
     * );
     * ```
     */
    update(id, body = {}, options) {
        return this._client.patch((0, path_1.path) `/v1/avatars/${id}`, { body, ...options });
    }
    /**
     * List avatars for the authenticated user with cursor-based pagination.
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const avatarListResponse of client.avatars.list({
     *   limit: 1,
     * })) {
     *   // ...
     * }
     * ```
     */
    list(query, options) {
        return this._client.getAPIList('/v1/avatars', (pagination_1.CursorPage), { query, ...options });
    }
    /**
     * Delete an avatar.
     *
     * @example
     * ```ts
     * await client.avatars.delete(
     *   '182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e',
     * );
     * ```
     */
    delete(id, options) {
        return this._client.delete((0, path_1.path) `/v1/avatars/${id}`, {
            ...options,
            headers: (0, headers_1.buildHeaders)([{ Accept: '*/*' }, options?.headers]),
        });
    }
    /**
     * Get aggregate usage statistics for avatar conversations, including total
     * duration, session counts, average duration, and a per-day breakdown. Per-day
     * buckets are keyed by UTC calendar date. The date range must not exceed 90 days.
     *
     * @example
     * ```ts
     * const response = await client.avatars.getUsage({
     *   endDate: '2019-12-27T18:11:19.117Z',
     *   startDate: '2019-12-27T18:11:19.117Z',
     * });
     * ```
     */
    getUsage(query, options) {
        return this._client.get('/v1/avatar_usage', { query, ...options });
    }
}
exports.Avatars = Avatars;
//# sourceMappingURL=avatars.js.map