import { APIResource } from "../core/resource.js";
import { APIPromise } from "../core/api-promise.js";
import { RequestOptions } from "../internal/request-options.js";
export declare class RealtimeSessions extends APIResource {
    /**
     * Create a new realtime session with the specified model configuration. The
     * returned ID is also the conversation ID used later to fetch transcripts and
     * recordings from the avatar conversation endpoints.
     */
    create(body: RealtimeSessionCreateParams, options?: RequestOptions): APIPromise<RealtimeSessionCreateResponse>;
    /**
     * Get the status of a realtime session. This endpoint uses the same ID that the
     * avatar conversation endpoints later expose as the conversation ID.
     */
    retrieve(id: string, options?: RequestOptions): APIPromise<RealtimeSessionRetrieveResponse>;
    /**
     * Cancel an active realtime session.
     */
    delete(id: string, options?: RequestOptions): APIPromise<void>;
}
export interface RealtimeSessionCreateResponse {
    /**
     * The ID of the created realtime session. This same value is later used as the
     * conversation ID in the avatar conversation endpoints.
     */
    id: string;
}
/**
 * A session that is being provisioned.
 */
export type RealtimeSessionRetrieveResponse = RealtimeSessionRetrieveResponse.NotReady | RealtimeSessionRetrieveResponse.Ready | RealtimeSessionRetrieveResponse.Running | RealtimeSessionRetrieveResponse.Completed | RealtimeSessionRetrieveResponse.Failed | RealtimeSessionRetrieveResponse.Cancelled;
export declare namespace RealtimeSessionRetrieveResponse {
    /**
     * A session that is being provisioned.
     */
    interface NotReady {
        /**
         * The realtime session ID. This same value is later used as the conversation ID in
         * the avatar conversation endpoints.
         */
        id: string;
        /**
         * When the session was created.
         */
        createdAt: string;
        status: 'NOT_READY';
        /**
         * When true, the session is waiting in a queue for available capacity. When false
         * or absent, the session is actively being provisioned.
         */
        queued?: boolean;
    }
    /**
     * A session that is ready to connect.
     */
    interface Ready {
        /**
         * The realtime session ID. This same value is later used as the conversation ID in
         * the avatar conversation endpoints.
         */
        id: string;
        /**
         * When the session was created.
         */
        createdAt: string;
        /**
         * When the session credentials expire.
         */
        expiresAt: string;
        /**
         * Session key for authenticating the /consume endpoint. Use as Bearer token.
         */
        sessionKey: string;
        status: 'READY';
    }
    /**
     * A session with an active WebRTC connection.
     */
    interface Running {
        /**
         * The realtime session ID. This same value is later used as the conversation ID in
         * the avatar conversation endpoints.
         */
        id: string;
        /**
         * When the session was created.
         */
        createdAt: string;
        status: 'RUNNING';
    }
    /**
     * A session that ended normally.
     */
    interface Completed {
        /**
         * The realtime session ID. This same value is later used as the conversation ID in
         * the avatar conversation endpoints.
         */
        id: string;
        /**
         * When the session was created.
         */
        createdAt: string;
        /**
         * The session duration in seconds.
         */
        duration: number;
        status: 'COMPLETED';
    }
    /**
     * A session that encountered an error.
     */
    interface Failed {
        /**
         * The realtime session ID. This same value is later used as the conversation ID in
         * the avatar conversation endpoints.
         */
        id: string;
        /**
         * When the session was created.
         */
        createdAt: string;
        /**
         * A human-readable error message. This value is not stable and should not be
         * matched against programmatically.
         */
        failure: string;
        /**
         * A stable, machine-readable error code. See
         * https://docs.dev.runwayml.com/errors/task-failures/ for more information.
         */
        failureCode: string;
        status: 'FAILED';
    }
    /**
     * A session that was explicitly cancelled.
     */
    interface Cancelled {
        /**
         * The realtime session ID. This same value is later used as the conversation ID in
         * the avatar conversation endpoints.
         */
        id: string;
        /**
         * When the session was created.
         */
        createdAt: string;
        status: 'CANCELLED';
    }
}
export interface RealtimeSessionCreateParams {
    /**
     * The avatar configuration for the session.
     */
    avatar: RealtimeSessionCreateParams.RunwayPreset | RealtimeSessionCreateParams.Custom;
    /**
     * The realtime session model type.
     */
    model: 'gwm1_avatars';
    /**
     * Maximum session duration in seconds.
     */
    maxDuration?: number;
    /**
     * Override the avatar personality for this session. If not provided, uses the
     * avatar default.
     */
    personality?: string;
    /**
     * Override the avatar start script for this session. If not provided, uses the
     * avatar default.
     */
    startScript?: string;
    /**
     * Tools available to the avatar during the session.
     */
    tools?: Array<RealtimeSessionCreateParams.ClientEvent | RealtimeSessionCreateParams.BackendRpc>;
}
export declare namespace RealtimeSessionCreateParams {
    /**
     * A preset avatar from Runway.
     */
    interface RunwayPreset {
        /**
         * ID of a preset avatar.
         */
        presetId: 'game-character' | 'music-superstar' | 'game-character-man' | 'cat-character' | 'influencer' | 'tennis-coach' | 'human-resource' | 'fashion-designer' | 'cooking-teacher';
        type: 'runway-preset';
    }
    /**
     * A user-created avatar.
     */
    interface Custom {
        /**
         * ID of a user-created avatar.
         */
        avatarId: string;
        type: 'custom';
    }
    /**
     * A fire-and-forget tool that sends arguments to the frontend client of the
     * realtime session.
     */
    interface ClientEvent {
        /**
         * A description of when and how the tool should be used. Be specific so the avatar
         * understands the right context to invoke it.
         */
        description: string;
        /**
         * The tool name. Must start with a letter or underscore, followed by alphanumeric
         * characters or underscores.
         */
        name: string;
        type: 'client_event';
        parameters?: Array<ClientEvent.String | ClientEvent.Integer | ClientEvent.Number | ClientEvent.Boolean | ClientEvent.Array_ | ClientEvent.Object>;
    }
    namespace ClientEvent {
        interface String {
            /**
             * A description of the parameter.
             */
            description: string;
            /**
             * The parameter name.
             */
            name: string;
            type: 'string';
            /**
             * Allowed values for the parameter.
             */
            enum?: Array<string>;
            /**
             * Whether the parameter is required.
             */
            required?: boolean;
        }
        interface Integer {
            /**
             * A description of the parameter.
             */
            description: string;
            /**
             * The parameter name.
             */
            name: string;
            type: 'integer';
            /**
             * Whether the parameter is required.
             */
            required?: boolean;
        }
        interface Number {
            /**
             * A description of the parameter.
             */
            description: string;
            /**
             * The parameter name.
             */
            name: string;
            type: 'number';
            /**
             * Whether the parameter is required.
             */
            required?: boolean;
        }
        interface Boolean {
            /**
             * A description of the parameter.
             */
            description: string;
            /**
             * The parameter name.
             */
            name: string;
            type: 'boolean';
            /**
             * Whether the parameter is required.
             */
            required?: boolean;
        }
        interface Array_ {
            /**
             * A description of the parameter.
             */
            description: string;
            /**
             * Item schema for array elements.
             */
            items: Array_.Items;
            /**
             * The parameter name.
             */
            name: string;
            type: 'array';
            /**
             * Whether the parameter is required.
             */
            required?: boolean;
        }
        namespace Array_ {
            /**
             * Item schema for array elements.
             */
            interface Items {
                /**
                 * The type of each element in the array.
                 */
                type: 'string' | 'integer' | 'number' | 'boolean';
            }
        }
        interface Object {
            /**
             * A description of the parameter.
             */
            description: string;
            /**
             * The parameter name.
             */
            name: string;
            /**
             * The properties of the object.
             */
            properties: Array<unknown>;
            type: 'object';
            /**
             * Whether the parameter is required.
             */
            required?: boolean;
        }
    }
    /**
     * A tool that makes a round-trip RPC call to your backend server during the
     * session.
     */
    interface BackendRpc {
        /**
         * A description of when and how the tool should be used. Be specific so the avatar
         * understands the right context to invoke it.
         */
        description: string;
        /**
         * The tool name. Must start with a letter or underscore, followed by alphanumeric
         * characters or underscores.
         */
        name: string;
        type: 'backend_rpc';
        parameters?: Array<BackendRpc.String | BackendRpc.Integer | BackendRpc.Number | BackendRpc.Boolean | BackendRpc.Array_ | BackendRpc.Object>;
        /**
         * Maximum time to wait for the backend to respond.
         */
        timeoutSeconds?: number;
    }
    namespace BackendRpc {
        interface String {
            /**
             * A description of the parameter.
             */
            description: string;
            /**
             * The parameter name.
             */
            name: string;
            type: 'string';
            /**
             * Allowed values for the parameter.
             */
            enum?: Array<string>;
            /**
             * Whether the parameter is required.
             */
            required?: boolean;
        }
        interface Integer {
            /**
             * A description of the parameter.
             */
            description: string;
            /**
             * The parameter name.
             */
            name: string;
            type: 'integer';
            /**
             * Whether the parameter is required.
             */
            required?: boolean;
        }
        interface Number {
            /**
             * A description of the parameter.
             */
            description: string;
            /**
             * The parameter name.
             */
            name: string;
            type: 'number';
            /**
             * Whether the parameter is required.
             */
            required?: boolean;
        }
        interface Boolean {
            /**
             * A description of the parameter.
             */
            description: string;
            /**
             * The parameter name.
             */
            name: string;
            type: 'boolean';
            /**
             * Whether the parameter is required.
             */
            required?: boolean;
        }
        interface Array_ {
            /**
             * A description of the parameter.
             */
            description: string;
            /**
             * Item schema for array elements.
             */
            items: Array_.Items;
            /**
             * The parameter name.
             */
            name: string;
            type: 'array';
            /**
             * Whether the parameter is required.
             */
            required?: boolean;
        }
        namespace Array_ {
            /**
             * Item schema for array elements.
             */
            interface Items {
                /**
                 * The type of each element in the array.
                 */
                type: 'string' | 'integer' | 'number' | 'boolean';
            }
        }
        interface Object {
            /**
             * A description of the parameter.
             */
            description: string;
            /**
             * The parameter name.
             */
            name: string;
            /**
             * The properties of the object.
             */
            properties: Array<unknown>;
            type: 'object';
            /**
             * Whether the parameter is required.
             */
            required?: boolean;
        }
    }
}
export declare namespace RealtimeSessions {
    export { type RealtimeSessionCreateResponse as RealtimeSessionCreateResponse, type RealtimeSessionRetrieveResponse as RealtimeSessionRetrieveResponse, type RealtimeSessionCreateParams as RealtimeSessionCreateParams, };
}
//# sourceMappingURL=realtime-sessions.d.ts.map