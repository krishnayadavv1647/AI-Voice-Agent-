// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../core/resource.mjs";
import { path } from "../internal/utils/path.mjs";
import { wrapAsWaitableWorkflowInvocation } from "../lib/polling.mjs";
export class WorkflowInvocations extends APIResource {
    /**
     * Return details about a workflow invocation. Consumers of this API should not
     * expect updates more frequent than once every five seconds for a given workflow
     * invocation.
     */
    retrieve(id, options) {
        return wrapAsWaitableWorkflowInvocation(this._client)(this._client.get(path `/v1/workflow_invocations/${id}`, options), true);
    }
}
//# sourceMappingURL=workflow-invocations.mjs.map