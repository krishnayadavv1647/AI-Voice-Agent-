// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../core/resource.mjs";
import { CursorPage } from "../core/pagination.mjs";
import { buildHeaders } from "../internal/headers.mjs";
import { path } from "../internal/utils/path.mjs";
export class Voices extends APIResource {
    /**
     * Create a custom voice from a text description, or clone a voice from an audio
     * sample.
     */
    create(body, options) {
        return this._client.post('/v1/voices', { body, ...options });
    }
    /**
     * Get details about a specific custom voice.
     */
    retrieve(id, options) {
        return this._client.get(path `/v1/voices/${id}`, options);
    }
    /**
     * Update the name and/or description of a custom voice.
     */
    update(id, body = {}, options) {
        return this._client.patch(path `/v1/voices/${id}`, { body, ...options });
    }
    /**
     * List custom voices for the authenticated organization with cursor-based
     * pagination.
     */
    list(query, options) {
        return this._client.getAPIList('/v1/voices', (CursorPage), { query, ...options });
    }
    /**
     * Delete a custom voice.
     */
    delete(id, options) {
        return this._client.delete(path `/v1/voices/${id}`, {
            ...options,
            headers: buildHeaders([{ Accept: '*/*' }, options?.headers]),
        });
    }
    /**
     * Generate a short audio preview of a voice from a text description. Use this to
     * audition a voice before creating it.
     */
    preview(body, options) {
        return this._client.post('/v1/voices/preview', { body, ...options });
    }
}
//# sourceMappingURL=voices.mjs.map