// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../core/resource.mjs";
import { wrapAsWaitableResource } from "../lib/polling.mjs";
/**
 * These endpoints all kick off tasks to create generations.
 */
export class TextToImage extends APIResource {
    /**
     * This endpoint will start a new task to generate images from text and/or image(s)
     */
    create(body, options) {
        return wrapAsWaitableResource(this._client)(this._client.post('/v1/text_to_image', { body, ...options }));
    }
}
//# sourceMappingURL=text-to-image.mjs.map