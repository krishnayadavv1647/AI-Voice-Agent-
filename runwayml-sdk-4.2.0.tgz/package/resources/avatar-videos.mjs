// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../core/resource.mjs";
import { wrapAsWaitableResource } from "../lib/polling.mjs";
export class AvatarVideos extends APIResource {
    /**
     * Start an asynchronous task to generate a video of an avatar speaking. Provide
     * `speech` with `type: "audio"` (audio file) or `type: "text"` (text script for
     * TTS). Poll `GET /v1/tasks/:id` to check progress and retrieve the output video
     * URL once complete.
     */
    create(body, options) {
        return wrapAsWaitableResource(this._client)(this._client.post('/v1/avatar_videos', { body, ...options }));
    }
}
//# sourceMappingURL=avatar-videos.mjs.map