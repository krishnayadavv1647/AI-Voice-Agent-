// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../core/resource.mjs";
import { wrapAsWaitableResource } from "../lib/polling.mjs";
/**
 * These endpoints all kick off tasks to create generations.
 */
export class CharacterPerformance extends APIResource {
    /**
     * This endpoint will start a new task to control a character's facial expressions
     * and body movements using a reference video.
     *
     * @example
     * ```ts
     * const characterPerformance =
     *   await client.characterPerformance.create({
     *     character: {
     *       type: 'image',
     *       uri: 'https://example.com/file',
     *     },
     *     model: 'act_two',
     *     reference: {
     *       type: 'video',
     *       uri: 'https://example.com/reference-performance.mp4',
     *     },
     *   });
     * ```
     */
    create(body, options) {
        return wrapAsWaitableResource(this._client)(this._client.post('/v1/character_performance', { body, ...options }));
    }
}
//# sourceMappingURL=character-performance.mjs.map