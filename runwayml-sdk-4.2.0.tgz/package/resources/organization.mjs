// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../core/resource.mjs";
export class Organization extends APIResource {
    /**
     * Get usage tier and credit balance information about the organization associated
     * with the API key used to make the request.
     */
    retrieve(options) {
        return this._client.get('/v1/organization', options);
    }
    /**
     * Fetch credit usage data broken down by model and day for the organization
     * associated with the API key used to make the request. Up to 90 days of data can
     * be queried at a time.
     */
    retrieveUsage(body = {}, options) {
        return this._client.post('/v1/organization/usage', { body, ...options });
    }
}
//# sourceMappingURL=organization.mjs.map