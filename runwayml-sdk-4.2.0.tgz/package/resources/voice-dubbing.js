"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.VoiceDubbing = void 0;
const resource_1 = require("../core/resource.js");
const polling_1 = require("../lib/polling.js");
/**
 * These endpoints all kick off tasks to create generations.
 */
class VoiceDubbing extends resource_1.APIResource {
    /**
     * This endpoint will start a new task to dub audio content to a target language.
     *
     * @example
     * ```ts
     * const voiceDubbing = await client.voiceDubbing.create({
     *   audioUri: 'https://example.com/audio.mp3',
     *   model: 'eleven_voice_dubbing',
     *   targetLang: 'en',
     * });
     * ```
     */
    create(body, options) {
        return (0, polling_1.wrapAsWaitableResource)(this._client)(this._client.post('/v1/voice_dubbing', { body, ...options }));
    }
}
exports.VoiceDubbing = VoiceDubbing;
//# sourceMappingURL=voice-dubbing.js.map