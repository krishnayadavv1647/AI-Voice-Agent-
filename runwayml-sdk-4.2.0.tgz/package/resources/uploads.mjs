// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../core/resource.mjs";
import { toFile } from "../internal/to-file.mjs";
import * as Errors from "../core/error.mjs";
import { castToError } from "../internal/errors.mjs";
async function uploadFileToStorage(uploadUrl, fields, file, fileMetadata, timeout, fetch) {
    const formData = new FormData();
    for (const [key, value] of Object.entries(fields)) {
        formData.append(key, value);
    }
    if (fileMetadata !== undefined) {
        formData.append('metadata', fileMetadata);
    }
    formData.append('file', file);
    const controller = new AbortController();
    const timeoutId = timeout ? setTimeout(() => controller.abort(), timeout) : undefined;
    try {
        const response = await fetch(uploadUrl, {
            method: 'POST',
            body: formData,
            signal: controller.signal,
        });
        if (!response.ok) {
            const errorText = await response.text().catch(() => '');
            throw new Errors.APIError(response.status, { error: errorText }, `Upload failed with status ${response.status}`, response.headers);
        }
    }
    catch (error) {
        if (error instanceof Errors.APIError) {
            throw error;
        }
        const err = castToError(error);
        if (err instanceof Error && err.name === 'AbortError') {
            throw new Errors.APIConnectionTimeoutError();
        }
        throw new Errors.APIConnectionError({ cause: err });
    }
    finally {
        if (timeoutId) {
            clearTimeout(timeoutId);
        }
    }
}
export class Uploads extends APIResource {
    /**
     * Uploads a temporary media file that can be used in other API generation
     * requests.
     *
     * The uploaded files will be automatically expired and deleted after a
     * period of time.
     */
    async createEphemeral(params, options) {
        const { file, fileMetadata } = params;
        const fileObj = await toFile(file);
        if (!fileObj.name || fileObj.name === 'unknown_file') {
            throw new Error('Cannot infer filename from file. Please provide a File with a name property, ' +
                'or use the toFile() utility with a name parameter to convert your data to a File.');
        }
        const placeholder = await this._client.post('/v1/uploads', {
            body: { filename: fileObj.name, type: 'ephemeral' },
            ...options,
        });
        const timeout = options?.timeout ?? this._client.timeout;
        // Access private fetch - using type assertion as it's needed for direct upload
        const fetch = this._client.fetch;
        await uploadFileToStorage(placeholder.uploadUrl, placeholder.fields, fileObj, fileMetadata, timeout, fetch);
        return { uri: placeholder.runwayUri };
    }
}
//# sourceMappingURL=uploads.mjs.map