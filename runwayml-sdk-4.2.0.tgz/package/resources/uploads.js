"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.Uploads = void 0;
const tslib_1 = require("../internal/tslib.js");
const resource_1 = require("../core/resource.js");
const to_file_1 = require("../internal/to-file.js");
const Errors = tslib_1.__importStar(require("../core/error.js"));
const errors_1 = require("../internal/errors.js");
async function uploadFileToStorage(uploadUrl, fields, file, fileMetadata, timeout, fetch) {
    const formData = new FormData();
    for (const [key, value] of Object.entries(fields)) {
        formData.append(key, value);
    }
    if (fileMetadata !== undefined) {
        formData.append('metadata', fileMetadata);
    }
    formData.append('file', file);
    const controller = new AbortController();
    const timeoutId = timeout ? setTimeout(() => controller.abort(), timeout) : undefined;
    try {
        const response = await fetch(uploadUrl, {
            method: 'POST',
            body: formData,
            signal: controller.signal,
        });
        if (!response.ok) {
            const errorText = await response.text().catch(() => '');
            throw new Errors.APIError(response.status, { error: errorText }, `Upload failed with status ${response.status}`, response.headers);
        }
    }
    catch (error) {
        if (error instanceof Errors.APIError) {
            throw error;
        }
        const err = (0, errors_1.castToError)(error);
        if (err instanceof Error && err.name === 'AbortError') {
            throw new Errors.APIConnectionTimeoutError();
        }
        throw new Errors.APIConnectionError({ cause: err });
    }
    finally {
        if (timeoutId) {
            clearTimeout(timeoutId);
        }
    }
}
class Uploads extends resource_1.APIResource {
    /**
     * Uploads a temporary media file that can be used in other API generation
     * requests.
     *
     * The uploaded files will be automatically expired and deleted after a
     * period of time.
     */
    async createEphemeral(params, options) {
        const { file, fileMetadata } = params;
        const fileObj = await (0, to_file_1.toFile)(file);
        if (!fileObj.name || fileObj.name === 'unknown_file') {
            throw new Error('Cannot infer filename from file. Please provide a File with a name property, ' +
                'or use the toFile() utility with a name parameter to convert your data to a File.');
        }
        const placeholder = await this._client.post('/v1/uploads', {
            body: { filename: fileObj.name, type: 'ephemeral' },
            ...options,
        });
        const timeout = options?.timeout ?? this._client.timeout;
        // Access private fetch - using type assertion as it's needed for direct upload
        const fetch = this._client.fetch;
        await uploadFileToStorage(placeholder.uploadUrl, placeholder.fields, fileObj, fileMetadata, timeout, fetch);
        return { uri: placeholder.runwayUri };
    }
}
exports.Uploads = Uploads;
//# sourceMappingURL=uploads.js.map