import { APIResource } from "../core/resource.mjs";
import { RequestOptions } from "../internal/request-options.mjs";
import { APIPromiseWithAwaitableTask } from "../lib/polling.mjs";
/**
 * These endpoints all kick off tasks to create generations.
 */
export declare class VoiceIsolation extends APIResource {
    /**
     * This endpoint will start a new task to isolate the voice from the background
     * audio. Audio duration must be greater than 4.6 seconds and less than 3600
     * seconds.
     *
     * @example
     * ```ts
     * const voiceIsolation = await client.voiceIsolation.create({
     *   audioUri: 'https://example.com/audio.mp3',
     *   model: 'eleven_voice_isolation',
     * });
     * ```
     */
    create(body: VoiceIsolationCreateParams, options?: RequestOptions): APIPromiseWithAwaitableTask<VoiceIsolationCreateResponse>;
}
export interface VoiceIsolationCreateResponse {
    /**
     * The ID of the task that was created. Use this to retrieve the task later.
     */
    id: string;
}
export interface VoiceIsolationCreateParams {
    /**
     * A HTTPS URL.
     */
    audioUri: string;
    model: 'eleven_voice_isolation';
}
export declare namespace VoiceIsolation {
    export { type VoiceIsolationCreateResponse as VoiceIsolationCreateResponse, type VoiceIsolationCreateParams as VoiceIsolationCreateParams, };
}
//# sourceMappingURL=voice-isolation.d.mts.map