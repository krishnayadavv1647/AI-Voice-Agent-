// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../core/resource.mjs";
import { buildHeaders } from "../internal/headers.mjs";
import { path } from "../internal/utils/path.mjs";
export class RealtimeSessions extends APIResource {
    /**
     * Create a new realtime session with the specified model configuration. The
     * returned ID is also the conversation ID used later to fetch transcripts and
     * recordings from the avatar conversation endpoints.
     */
    create(body, options) {
        return this._client.post('/v1/realtime_sessions', { body, ...options });
    }
    /**
     * Get the status of a realtime session. This endpoint uses the same ID that the
     * avatar conversation endpoints later expose as the conversation ID.
     */
    retrieve(id, options) {
        return this._client.get(path `/v1/realtime_sessions/${id}`, options);
    }
    /**
     * Cancel an active realtime session.
     */
    delete(id, options) {
        return this._client.delete(path `/v1/realtime_sessions/${id}`, {
            ...options,
            headers: buildHeaders([{ Accept: '*/*' }, options?.headers]),
        });
    }
}
//# sourceMappingURL=realtime-sessions.mjs.map