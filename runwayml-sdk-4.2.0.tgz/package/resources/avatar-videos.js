"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.AvatarVideos = void 0;
const resource_1 = require("../core/resource.js");
const polling_1 = require("../lib/polling.js");
class AvatarVideos extends resource_1.APIResource {
    /**
     * Start an asynchronous task to generate a video of an avatar speaking. Provide
     * `speech` with `type: "audio"` (audio file) or `type: "text"` (text script for
     * TTS). Poll `GET /v1/tasks/:id` to check progress and retrieve the output video
     * URL once complete.
     */
    create(body, options) {
        return (0, polling_1.wrapAsWaitableResource)(this._client)(this._client.post('/v1/avatar_videos', { body, ...options }));
    }
}
exports.AvatarVideos = AvatarVideos;
//# sourceMappingURL=avatar-videos.js.map