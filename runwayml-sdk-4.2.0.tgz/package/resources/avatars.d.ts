import { APIResource } from "../core/resource.js";
import { APIPromise } from "../core/api-promise.js";
import { CursorPage, type CursorPageParams, PagePromise } from "../core/pagination.js";
import { RequestOptions } from "../internal/request-options.js";
export declare class Avatars extends APIResource {
    /**
     * Create a new avatar with a reference image and voice.
     *
     * @example
     * ```ts
     * const avatar = await client.avatars.create({
     *   name: 'x',
     *   personality:
     *     'You are a helpful support agent assisting users with their account questions. Be friendly, patient, and provide clear step-by-step guidance.',
     *   referenceImage: 'https://example.com/reference.jpg',
     *   voice: { presetId: 'adrian', type: 'runway-live-preset' },
     * });
     * ```
     */
    create(body: AvatarCreateParams, options?: RequestOptions): APIPromise<AvatarCreateResponse>;
    /**
     * Get details of a specific avatar.
     *
     * @example
     * ```ts
     * const avatar = await client.avatars.retrieve(
     *   '182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e',
     * );
     * ```
     */
    retrieve(id: string, options?: RequestOptions): APIPromise<AvatarRetrieveResponse>;
    /**
     * Update an existing avatar. At least one field must be provided.
     *
     * @example
     * ```ts
     * const avatar = await client.avatars.update(
     *   '182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e',
     * );
     * ```
     */
    update(id: string, body?: AvatarUpdateParams | null | undefined, options?: RequestOptions): APIPromise<AvatarUpdateResponse>;
    /**
     * List avatars for the authenticated user with cursor-based pagination.
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const avatarListResponse of client.avatars.list({
     *   limit: 1,
     * })) {
     *   // ...
     * }
     * ```
     */
    list(query: AvatarListParams, options?: RequestOptions): PagePromise<AvatarListResponsesCursorPage, AvatarListResponse>;
    /**
     * Delete an avatar.
     *
     * @example
     * ```ts
     * await client.avatars.delete(
     *   '182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e',
     * );
     * ```
     */
    delete(id: string, options?: RequestOptions): APIPromise<void>;
    /**
     * Get aggregate usage statistics for avatar conversations, including total
     * duration, session counts, average duration, and a per-day breakdown. Per-day
     * buckets are keyed by UTC calendar date. The date range must not exceed 90 days.
     *
     * @example
     * ```ts
     * const response = await client.avatars.getUsage({
     *   endDate: '2019-12-27T18:11:19.117Z',
     *   startDate: '2019-12-27T18:11:19.117Z',
     * });
     * ```
     */
    getUsage(query: AvatarGetUsageParams, options?: RequestOptions): APIPromise<AvatarGetUsageResponse>;
}
export type AvatarListResponsesCursorPage = CursorPage<AvatarListResponse>;
/**
 * An avatar that is still being processed.
 */
export type AvatarCreateResponse = AvatarCreateResponse.Processing | AvatarCreateResponse.Ready | AvatarCreateResponse.Failed;
export declare namespace AvatarCreateResponse {
    /**
     * An avatar that is still being processed.
     */
    interface Processing {
        /**
         * The unique identifier of the avatar.
         */
        id: string;
        /**
         * When the avatar was created.
         */
        createdAt: string;
        /**
         * IDs of knowledge documents attached to this avatar.
         */
        documentIds: Array<string>;
        /**
         * The character name for the avatar.
         */
        name: string;
        /**
         * System prompt defining how the avatar should behave in conversations.
         */
        personality: string;
        /**
         * A URI pointing to a low-resolution preview of the processed reference image.
         */
        processedImageUri: string | null;
        /**
         * A URI pointing to a low-resolution preview of the avatar's reference image.
         */
        referenceImageUri: string | null;
        /**
         * Opening message that the avatar will say when a session starts, or null if not
         * set.
         */
        startScript: string | null;
        status: 'PROCESSING';
        /**
         * When the avatar was last updated.
         */
        updatedAt: string;
        /**
         * The voice configured for this avatar.
         */
        voice: Processing.RunwayLivePreset | Processing.Custom;
    }
    namespace Processing {
        /**
         * A preset voice from the Runway API.
         */
        interface RunwayLivePreset {
            /**
             * A brief description of the voice characteristics.
             */
            description: string;
            /**
             * The display name of the voice.
             */
            name: string;
            /**
             * The preset voice identifier.
             */
            presetId: 'victoria' | 'vincent' | 'clara' | 'drew' | 'skye' | 'max' | 'morgan' | 'felix' | 'mia' | 'marcus' | 'summer' | 'ruby' | 'aurora' | 'jasper' | 'leo' | 'adrian' | 'nina' | 'emma' | 'blake' | 'david' | 'maya' | 'nathan' | 'sam' | 'georgia' | 'petra' | 'adam' | 'zach' | 'violet' | 'roman' | 'luna';
            type: 'runway-live-preset';
        }
        /**
         * A custom voice created via the Voices API.
         */
        interface Custom {
            /**
             * The unique identifier of the custom voice.
             */
            id: string;
            /**
             * Whether the voice has been deleted. When true, name and description are omitted.
             */
            deleted: boolean;
            type: 'custom';
            /**
             * A brief description of the voice characteristics.
             */
            description?: string | null;
            /**
             * The display name of the voice.
             */
            name?: string;
        }
    }
    /**
     * An avatar that is ready for use in sessions.
     */
    interface Ready {
        /**
         * The unique identifier of the avatar.
         */
        id: string;
        /**
         * When the avatar was created.
         */
        createdAt: string;
        /**
         * IDs of knowledge documents attached to this avatar.
         */
        documentIds: Array<string>;
        /**
         * The character name for the avatar.
         */
        name: string;
        /**
         * System prompt defining how the avatar should behave in conversations.
         */
        personality: string;
        /**
         * A URI pointing to a low-resolution preview of the processed reference image.
         */
        processedImageUri: string | null;
        /**
         * A URI pointing to a low-resolution preview of the avatar's reference image.
         */
        referenceImageUri: string | null;
        /**
         * Opening message that the avatar will say when a session starts, or null if not
         * set.
         */
        startScript: string | null;
        status: 'READY';
        /**
         * When the avatar was last updated.
         */
        updatedAt: string;
        /**
         * The voice configured for this avatar.
         */
        voice: Ready.RunwayLivePreset | Ready.Custom;
    }
    namespace Ready {
        /**
         * A preset voice from the Runway API.
         */
        interface RunwayLivePreset {
            /**
             * A brief description of the voice characteristics.
             */
            description: string;
            /**
             * The display name of the voice.
             */
            name: string;
            /**
             * The preset voice identifier.
             */
            presetId: 'victoria' | 'vincent' | 'clara' | 'drew' | 'skye' | 'max' | 'morgan' | 'felix' | 'mia' | 'marcus' | 'summer' | 'ruby' | 'aurora' | 'jasper' | 'leo' | 'adrian' | 'nina' | 'emma' | 'blake' | 'david' | 'maya' | 'nathan' | 'sam' | 'georgia' | 'petra' | 'adam' | 'zach' | 'violet' | 'roman' | 'luna';
            type: 'runway-live-preset';
        }
        /**
         * A custom voice created via the Voices API.
         */
        interface Custom {
            /**
             * The unique identifier of the custom voice.
             */
            id: string;
            /**
             * Whether the voice has been deleted. When true, name and description are omitted.
             */
            deleted: boolean;
            type: 'custom';
            /**
             * A brief description of the voice characteristics.
             */
            description?: string | null;
            /**
             * The display name of the voice.
             */
            name?: string;
        }
    }
    /**
     * An avatar that failed to finish processing.
     */
    interface Failed {
        /**
         * The unique identifier of the avatar.
         */
        id: string;
        /**
         * When the avatar was created.
         */
        createdAt: string;
        /**
         * IDs of knowledge documents attached to this avatar.
         */
        documentIds: Array<string>;
        /**
         * A human-readable error message. This value is not stable and should not be
         * matched against programmatically.
         */
        failureReason: string;
        /**
         * The character name for the avatar.
         */
        name: string;
        /**
         * System prompt defining how the avatar should behave in conversations.
         */
        personality: string;
        /**
         * A URI pointing to a low-resolution preview of the processed reference image.
         */
        processedImageUri: string | null;
        /**
         * A URI pointing to a low-resolution preview of the avatar's reference image.
         */
        referenceImageUri: string | null;
        /**
         * Opening message that the avatar will say when a session starts, or null if not
         * set.
         */
        startScript: string | null;
        status: 'FAILED';
        /**
         * When the avatar was last updated.
         */
        updatedAt: string;
        /**
         * The voice configured for this avatar.
         */
        voice: Failed.RunwayLivePreset | Failed.Custom;
    }
    namespace Failed {
        /**
         * A preset voice from the Runway API.
         */
        interface RunwayLivePreset {
            /**
             * A brief description of the voice characteristics.
             */
            description: string;
            /**
             * The display name of the voice.
             */
            name: string;
            /**
             * The preset voice identifier.
             */
            presetId: 'victoria' | 'vincent' | 'clara' | 'drew' | 'skye' | 'max' | 'morgan' | 'felix' | 'mia' | 'marcus' | 'summer' | 'ruby' | 'aurora' | 'jasper' | 'leo' | 'adrian' | 'nina' | 'emma' | 'blake' | 'david' | 'maya' | 'nathan' | 'sam' | 'georgia' | 'petra' | 'adam' | 'zach' | 'violet' | 'roman' | 'luna';
            type: 'runway-live-preset';
        }
        /**
         * A custom voice created via the Voices API.
         */
        interface Custom {
            /**
             * The unique identifier of the custom voice.
             */
            id: string;
            /**
             * Whether the voice has been deleted. When true, name and description are omitted.
             */
            deleted: boolean;
            type: 'custom';
            /**
             * A brief description of the voice characteristics.
             */
            description?: string | null;
            /**
             * The display name of the voice.
             */
            name?: string;
        }
    }
}
/**
 * An avatar that is still being processed.
 */
export type AvatarRetrieveResponse = AvatarRetrieveResponse.Processing | AvatarRetrieveResponse.Ready | AvatarRetrieveResponse.Failed;
export declare namespace AvatarRetrieveResponse {
    /**
     * An avatar that is still being processed.
     */
    interface Processing {
        /**
         * The unique identifier of the avatar.
         */
        id: string;
        /**
         * When the avatar was created.
         */
        createdAt: string;
        /**
         * IDs of knowledge documents attached to this avatar.
         */
        documentIds: Array<string>;
        /**
         * The character name for the avatar.
         */
        name: string;
        /**
         * System prompt defining how the avatar should behave in conversations.
         */
        personality: string;
        /**
         * A URI pointing to a low-resolution preview of the processed reference image.
         */
        processedImageUri: string | null;
        /**
         * A URI pointing to a low-resolution preview of the avatar's reference image.
         */
        referenceImageUri: string | null;
        /**
         * Opening message that the avatar will say when a session starts, or null if not
         * set.
         */
        startScript: string | null;
        status: 'PROCESSING';
        /**
         * When the avatar was last updated.
         */
        updatedAt: string;
        /**
         * The voice configured for this avatar.
         */
        voice: Processing.RunwayLivePreset | Processing.Custom;
    }
    namespace Processing {
        /**
         * A preset voice from the Runway API.
         */
        interface RunwayLivePreset {
            /**
             * A brief description of the voice characteristics.
             */
            description: string;
            /**
             * The display name of the voice.
             */
            name: string;
            /**
             * The preset voice identifier.
             */
            presetId: 'victoria' | 'vincent' | 'clara' | 'drew' | 'skye' | 'max' | 'morgan' | 'felix' | 'mia' | 'marcus' | 'summer' | 'ruby' | 'aurora' | 'jasper' | 'leo' | 'adrian' | 'nina' | 'emma' | 'blake' | 'david' | 'maya' | 'nathan' | 'sam' | 'georgia' | 'petra' | 'adam' | 'zach' | 'violet' | 'roman' | 'luna';
            type: 'runway-live-preset';
        }
        /**
         * A custom voice created via the Voices API.
         */
        interface Custom {
            /**
             * The unique identifier of the custom voice.
             */
            id: string;
            /**
             * Whether the voice has been deleted. When true, name and description are omitted.
             */
            deleted: boolean;
            type: 'custom';
            /**
             * A brief description of the voice characteristics.
             */
            description?: string | null;
            /**
             * The display name of the voice.
             */
            name?: string;
        }
    }
    /**
     * An avatar that is ready for use in sessions.
     */
    interface Ready {
        /**
         * The unique identifier of the avatar.
         */
        id: string;
        /**
         * When the avatar was created.
         */
        createdAt: string;
        /**
         * IDs of knowledge documents attached to this avatar.
         */
        documentIds: Array<string>;
        /**
         * The character name for the avatar.
         */
        name: string;
        /**
         * System prompt defining how the avatar should behave in conversations.
         */
        personality: string;
        /**
         * A URI pointing to a low-resolution preview of the processed reference image.
         */
        processedImageUri: string | null;
        /**
         * A URI pointing to a low-resolution preview of the avatar's reference image.
         */
        referenceImageUri: string | null;
        /**
         * Opening message that the avatar will say when a session starts, or null if not
         * set.
         */
        startScript: string | null;
        status: 'READY';
        /**
         * When the avatar was last updated.
         */
        updatedAt: string;
        /**
         * The voice configured for this avatar.
         */
        voice: Ready.RunwayLivePreset | Ready.Custom;
    }
    namespace Ready {
        /**
         * A preset voice from the Runway API.
         */
        interface RunwayLivePreset {
            /**
             * A brief description of the voice characteristics.
             */
            description: string;
            /**
             * The display name of the voice.
             */
            name: string;
            /**
             * The preset voice identifier.
             */
            presetId: 'victoria' | 'vincent' | 'clara' | 'drew' | 'skye' | 'max' | 'morgan' | 'felix' | 'mia' | 'marcus' | 'summer' | 'ruby' | 'aurora' | 'jasper' | 'leo' | 'adrian' | 'nina' | 'emma' | 'blake' | 'david' | 'maya' | 'nathan' | 'sam' | 'georgia' | 'petra' | 'adam' | 'zach' | 'violet' | 'roman' | 'luna';
            type: 'runway-live-preset';
        }
        /**
         * A custom voice created via the Voices API.
         */
        interface Custom {
            /**
             * The unique identifier of the custom voice.
             */
            id: string;
            /**
             * Whether the voice has been deleted. When true, name and description are omitted.
             */
            deleted: boolean;
            type: 'custom';
            /**
             * A brief description of the voice characteristics.
             */
            description?: string | null;
            /**
             * The display name of the voice.
             */
            name?: string;
        }
    }
    /**
     * An avatar that failed to finish processing.
     */
    interface Failed {
        /**
         * The unique identifier of the avatar.
         */
        id: string;
        /**
         * When the avatar was created.
         */
        createdAt: string;
        /**
         * IDs of knowledge documents attached to this avatar.
         */
        documentIds: Array<string>;
        /**
         * A human-readable error message. This value is not stable and should not be
         * matched against programmatically.
         */
        failureReason: string;
        /**
         * The character name for the avatar.
         */
        name: string;
        /**
         * System prompt defining how the avatar should behave in conversations.
         */
        personality: string;
        /**
         * A URI pointing to a low-resolution preview of the processed reference image.
         */
        processedImageUri: string | null;
        /**
         * A URI pointing to a low-resolution preview of the avatar's reference image.
         */
        referenceImageUri: string | null;
        /**
         * Opening message that the avatar will say when a session starts, or null if not
         * set.
         */
        startScript: string | null;
        status: 'FAILED';
        /**
         * When the avatar was last updated.
         */
        updatedAt: string;
        /**
         * The voice configured for this avatar.
         */
        voice: Failed.RunwayLivePreset | Failed.Custom;
    }
    namespace Failed {
        /**
         * A preset voice from the Runway API.
         */
        interface RunwayLivePreset {
            /**
             * A brief description of the voice characteristics.
             */
            description: string;
            /**
             * The display name of the voice.
             */
            name: string;
            /**
             * The preset voice identifier.
             */
            presetId: 'victoria' | 'vincent' | 'clara' | 'drew' | 'skye' | 'max' | 'morgan' | 'felix' | 'mia' | 'marcus' | 'summer' | 'ruby' | 'aurora' | 'jasper' | 'leo' | 'adrian' | 'nina' | 'emma' | 'blake' | 'david' | 'maya' | 'nathan' | 'sam' | 'georgia' | 'petra' | 'adam' | 'zach' | 'violet' | 'roman' | 'luna';
            type: 'runway-live-preset';
        }
        /**
         * A custom voice created via the Voices API.
         */
        interface Custom {
            /**
             * The unique identifier of the custom voice.
             */
            id: string;
            /**
             * Whether the voice has been deleted. When true, name and description are omitted.
             */
            deleted: boolean;
            type: 'custom';
            /**
             * A brief description of the voice characteristics.
             */
            description?: string | null;
            /**
             * The display name of the voice.
             */
            name?: string;
        }
    }
}
/**
 * An avatar that is still being processed.
 */
export type AvatarUpdateResponse = AvatarUpdateResponse.Processing | AvatarUpdateResponse.Ready | AvatarUpdateResponse.Failed;
export declare namespace AvatarUpdateResponse {
    /**
     * An avatar that is still being processed.
     */
    interface Processing {
        /**
         * The unique identifier of the avatar.
         */
        id: string;
        /**
         * When the avatar was created.
         */
        createdAt: string;
        /**
         * IDs of knowledge documents attached to this avatar.
         */
        documentIds: Array<string>;
        /**
         * The character name for the avatar.
         */
        name: string;
        /**
         * System prompt defining how the avatar should behave in conversations.
         */
        personality: string;
        /**
         * A URI pointing to a low-resolution preview of the processed reference image.
         */
        processedImageUri: string | null;
        /**
         * A URI pointing to a low-resolution preview of the avatar's reference image.
         */
        referenceImageUri: string | null;
        /**
         * Opening message that the avatar will say when a session starts, or null if not
         * set.
         */
        startScript: string | null;
        status: 'PROCESSING';
        /**
         * When the avatar was last updated.
         */
        updatedAt: string;
        /**
         * The voice configured for this avatar.
         */
        voice: Processing.RunwayLivePreset | Processing.Custom;
    }
    namespace Processing {
        /**
         * A preset voice from the Runway API.
         */
        interface RunwayLivePreset {
            /**
             * A brief description of the voice characteristics.
             */
            description: string;
            /**
             * The display name of the voice.
             */
            name: string;
            /**
             * The preset voice identifier.
             */
            presetId: 'victoria' | 'vincent' | 'clara' | 'drew' | 'skye' | 'max' | 'morgan' | 'felix' | 'mia' | 'marcus' | 'summer' | 'ruby' | 'aurora' | 'jasper' | 'leo' | 'adrian' | 'nina' | 'emma' | 'blake' | 'david' | 'maya' | 'nathan' | 'sam' | 'georgia' | 'petra' | 'adam' | 'zach' | 'violet' | 'roman' | 'luna';
            type: 'runway-live-preset';
        }
        /**
         * A custom voice created via the Voices API.
         */
        interface Custom {
            /**
             * The unique identifier of the custom voice.
             */
            id: string;
            /**
             * Whether the voice has been deleted. When true, name and description are omitted.
             */
            deleted: boolean;
            type: 'custom';
            /**
             * A brief description of the voice characteristics.
             */
            description?: string | null;
            /**
             * The display name of the voice.
             */
            name?: string;
        }
    }
    /**
     * An avatar that is ready for use in sessions.
     */
    interface Ready {
        /**
         * The unique identifier of the avatar.
         */
        id: string;
        /**
         * When the avatar was created.
         */
        createdAt: string;
        /**
         * IDs of knowledge documents attached to this avatar.
         */
        documentIds: Array<string>;
        /**
         * The character name for the avatar.
         */
        name: string;
        /**
         * System prompt defining how the avatar should behave in conversations.
         */
        personality: string;
        /**
         * A URI pointing to a low-resolution preview of the processed reference image.
         */
        processedImageUri: string | null;
        /**
         * A URI pointing to a low-resolution preview of the avatar's reference image.
         */
        referenceImageUri: string | null;
        /**
         * Opening message that the avatar will say when a session starts, or null if not
         * set.
         */
        startScript: string | null;
        status: 'READY';
        /**
         * When the avatar was last updated.
         */
        updatedAt: string;
        /**
         * The voice configured for this avatar.
         */
        voice: Ready.RunwayLivePreset | Ready.Custom;
    }
    namespace Ready {
        /**
         * A preset voice from the Runway API.
         */
        interface RunwayLivePreset {
            /**
             * A brief description of the voice characteristics.
             */
            description: string;
            /**
             * The display name of the voice.
             */
            name: string;
            /**
             * The preset voice identifier.
             */
            presetId: 'victoria' | 'vincent' | 'clara' | 'drew' | 'skye' | 'max' | 'morgan' | 'felix' | 'mia' | 'marcus' | 'summer' | 'ruby' | 'aurora' | 'jasper' | 'leo' | 'adrian' | 'nina' | 'emma' | 'blake' | 'david' | 'maya' | 'nathan' | 'sam' | 'georgia' | 'petra' | 'adam' | 'zach' | 'violet' | 'roman' | 'luna';
            type: 'runway-live-preset';
        }
        /**
         * A custom voice created via the Voices API.
         */
        interface Custom {
            /**
             * The unique identifier of the custom voice.
             */
            id: string;
            /**
             * Whether the voice has been deleted. When true, name and description are omitted.
             */
            deleted: boolean;
            type: 'custom';
            /**
             * A brief description of the voice characteristics.
             */
            description?: string | null;
            /**
             * The display name of the voice.
             */
            name?: string;
        }
    }
    /**
     * An avatar that failed to finish processing.
     */
    interface Failed {
        /**
         * The unique identifier of the avatar.
         */
        id: string;
        /**
         * When the avatar was created.
         */
        createdAt: string;
        /**
         * IDs of knowledge documents attached to this avatar.
         */
        documentIds: Array<string>;
        /**
         * A human-readable error message. This value is not stable and should not be
         * matched against programmatically.
         */
        failureReason: string;
        /**
         * The character name for the avatar.
         */
        name: string;
        /**
         * System prompt defining how the avatar should behave in conversations.
         */
        personality: string;
        /**
         * A URI pointing to a low-resolution preview of the processed reference image.
         */
        processedImageUri: string | null;
        /**
         * A URI pointing to a low-resolution preview of the avatar's reference image.
         */
        referenceImageUri: string | null;
        /**
         * Opening message that the avatar will say when a session starts, or null if not
         * set.
         */
        startScript: string | null;
        status: 'FAILED';
        /**
         * When the avatar was last updated.
         */
        updatedAt: string;
        /**
         * The voice configured for this avatar.
         */
        voice: Failed.RunwayLivePreset | Failed.Custom;
    }
    namespace Failed {
        /**
         * A preset voice from the Runway API.
         */
        interface RunwayLivePreset {
            /**
             * A brief description of the voice characteristics.
             */
            description: string;
            /**
             * The display name of the voice.
             */
            name: string;
            /**
             * The preset voice identifier.
             */
            presetId: 'victoria' | 'vincent' | 'clara' | 'drew' | 'skye' | 'max' | 'morgan' | 'felix' | 'mia' | 'marcus' | 'summer' | 'ruby' | 'aurora' | 'jasper' | 'leo' | 'adrian' | 'nina' | 'emma' | 'blake' | 'david' | 'maya' | 'nathan' | 'sam' | 'georgia' | 'petra' | 'adam' | 'zach' | 'violet' | 'roman' | 'luna';
            type: 'runway-live-preset';
        }
        /**
         * A custom voice created via the Voices API.
         */
        interface Custom {
            /**
             * The unique identifier of the custom voice.
             */
            id: string;
            /**
             * Whether the voice has been deleted. When true, name and description are omitted.
             */
            deleted: boolean;
            type: 'custom';
            /**
             * A brief description of the voice characteristics.
             */
            description?: string | null;
            /**
             * The display name of the voice.
             */
            name?: string;
        }
    }
}
/**
 * An avatar that is still being processed.
 */
export type AvatarListResponse = AvatarListResponse.Processing | AvatarListResponse.Ready | AvatarListResponse.Failed;
export declare namespace AvatarListResponse {
    /**
     * An avatar that is still being processed.
     */
    interface Processing {
        /**
         * The unique identifier of the avatar.
         */
        id: string;
        /**
         * When the avatar was created.
         */
        createdAt: string;
        /**
         * IDs of knowledge documents attached to this avatar.
         */
        documentIds: Array<string>;
        /**
         * The character name for the avatar.
         */
        name: string;
        /**
         * System prompt defining how the avatar should behave in conversations.
         */
        personality: string;
        /**
         * A URI pointing to a low-resolution preview of the processed reference image.
         */
        processedImageUri: string | null;
        /**
         * A URI pointing to a low-resolution preview of the avatar's reference image.
         */
        referenceImageUri: string | null;
        /**
         * Opening message that the avatar will say when a session starts, or null if not
         * set.
         */
        startScript: string | null;
        status: 'PROCESSING';
        /**
         * When the avatar was last updated.
         */
        updatedAt: string;
        /**
         * The voice configured for this avatar.
         */
        voice: Processing.RunwayLivePreset | Processing.Custom;
    }
    namespace Processing {
        /**
         * A preset voice from the Runway API.
         */
        interface RunwayLivePreset {
            /**
             * A brief description of the voice characteristics.
             */
            description: string;
            /**
             * The display name of the voice.
             */
            name: string;
            /**
             * The preset voice identifier.
             */
            presetId: 'victoria' | 'vincent' | 'clara' | 'drew' | 'skye' | 'max' | 'morgan' | 'felix' | 'mia' | 'marcus' | 'summer' | 'ruby' | 'aurora' | 'jasper' | 'leo' | 'adrian' | 'nina' | 'emma' | 'blake' | 'david' | 'maya' | 'nathan' | 'sam' | 'georgia' | 'petra' | 'adam' | 'zach' | 'violet' | 'roman' | 'luna';
            type: 'runway-live-preset';
        }
        /**
         * A custom voice created via the Voices API.
         */
        interface Custom {
            /**
             * The unique identifier of the custom voice.
             */
            id: string;
            /**
             * Whether the voice has been deleted. When true, name and description are omitted.
             */
            deleted: boolean;
            type: 'custom';
            /**
             * A brief description of the voice characteristics.
             */
            description?: string | null;
            /**
             * The display name of the voice.
             */
            name?: string;
        }
    }
    /**
     * An avatar that is ready for use in sessions.
     */
    interface Ready {
        /**
         * The unique identifier of the avatar.
         */
        id: string;
        /**
         * When the avatar was created.
         */
        createdAt: string;
        /**
         * IDs of knowledge documents attached to this avatar.
         */
        documentIds: Array<string>;
        /**
         * The character name for the avatar.
         */
        name: string;
        /**
         * System prompt defining how the avatar should behave in conversations.
         */
        personality: string;
        /**
         * A URI pointing to a low-resolution preview of the processed reference image.
         */
        processedImageUri: string | null;
        /**
         * A URI pointing to a low-resolution preview of the avatar's reference image.
         */
        referenceImageUri: string | null;
        /**
         * Opening message that the avatar will say when a session starts, or null if not
         * set.
         */
        startScript: string | null;
        status: 'READY';
        /**
         * When the avatar was last updated.
         */
        updatedAt: string;
        /**
         * The voice configured for this avatar.
         */
        voice: Ready.RunwayLivePreset | Ready.Custom;
    }
    namespace Ready {
        /**
         * A preset voice from the Runway API.
         */
        interface RunwayLivePreset {
            /**
             * A brief description of the voice characteristics.
             */
            description: string;
            /**
             * The display name of the voice.
             */
            name: string;
            /**
             * The preset voice identifier.
             */
            presetId: 'victoria' | 'vincent' | 'clara' | 'drew' | 'skye' | 'max' | 'morgan' | 'felix' | 'mia' | 'marcus' | 'summer' | 'ruby' | 'aurora' | 'jasper' | 'leo' | 'adrian' | 'nina' | 'emma' | 'blake' | 'david' | 'maya' | 'nathan' | 'sam' | 'georgia' | 'petra' | 'adam' | 'zach' | 'violet' | 'roman' | 'luna';
            type: 'runway-live-preset';
        }
        /**
         * A custom voice created via the Voices API.
         */
        interface Custom {
            /**
             * The unique identifier of the custom voice.
             */
            id: string;
            /**
             * Whether the voice has been deleted. When true, name and description are omitted.
             */
            deleted: boolean;
            type: 'custom';
            /**
             * A brief description of the voice characteristics.
             */
            description?: string | null;
            /**
             * The display name of the voice.
             */
            name?: string;
        }
    }
    /**
     * An avatar that failed to finish processing.
     */
    interface Failed {
        /**
         * The unique identifier of the avatar.
         */
        id: string;
        /**
         * When the avatar was created.
         */
        createdAt: string;
        /**
         * IDs of knowledge documents attached to this avatar.
         */
        documentIds: Array<string>;
        /**
         * A human-readable error message. This value is not stable and should not be
         * matched against programmatically.
         */
        failureReason: string;
        /**
         * The character name for the avatar.
         */
        name: string;
        /**
         * System prompt defining how the avatar should behave in conversations.
         */
        personality: string;
        /**
         * A URI pointing to a low-resolution preview of the processed reference image.
         */
        processedImageUri: string | null;
        /**
         * A URI pointing to a low-resolution preview of the avatar's reference image.
         */
        referenceImageUri: string | null;
        /**
         * Opening message that the avatar will say when a session starts, or null if not
         * set.
         */
        startScript: string | null;
        status: 'FAILED';
        /**
         * When the avatar was last updated.
         */
        updatedAt: string;
        /**
         * The voice configured for this avatar.
         */
        voice: Failed.RunwayLivePreset | Failed.Custom;
    }
    namespace Failed {
        /**
         * A preset voice from the Runway API.
         */
        interface RunwayLivePreset {
            /**
             * A brief description of the voice characteristics.
             */
            description: string;
            /**
             * The display name of the voice.
             */
            name: string;
            /**
             * The preset voice identifier.
             */
            presetId: 'victoria' | 'vincent' | 'clara' | 'drew' | 'skye' | 'max' | 'morgan' | 'felix' | 'mia' | 'marcus' | 'summer' | 'ruby' | 'aurora' | 'jasper' | 'leo' | 'adrian' | 'nina' | 'emma' | 'blake' | 'david' | 'maya' | 'nathan' | 'sam' | 'georgia' | 'petra' | 'adam' | 'zach' | 'violet' | 'roman' | 'luna';
            type: 'runway-live-preset';
        }
        /**
         * A custom voice created via the Voices API.
         */
        interface Custom {
            /**
             * The unique identifier of the custom voice.
             */
            id: string;
            /**
             * Whether the voice has been deleted. When true, name and description are omitted.
             */
            deleted: boolean;
            type: 'custom';
            /**
             * A brief description of the voice characteristics.
             */
            description?: string | null;
            /**
             * The display name of the voice.
             */
            name?: string;
        }
    }
}
export interface AvatarGetUsageResponse {
    /**
     * Average duration in seconds across conversations with a measured duration, or 0
     * if none completed. May not equal `totalSeconds / totalSessions` because
     * unfinished conversations contribute to the session count but not the duration.
     */
    avgDurationSeconds: number;
    /**
     * Per-day usage across the date range. Days with no sessions are included with
     * zeroes.
     */
    byDay: Array<AvatarGetUsageResponse.ByDay>;
    /**
     * Total seconds across conversations with a measured duration in the date range.
     */
    totalSeconds: number;
    /**
     * Number of conversations started in the date range. Includes unfinished and
     * failed conversations.
     */
    totalSessions: number;
}
export declare namespace AvatarGetUsageResponse {
    interface ByDay {
        /**
         * The UTC calendar date (YYYY-MM-DD).
         */
        date: string;
        /**
         * Total seconds of measured conversation duration on this date.
         */
        seconds: number;
        /**
         * Number of conversations started on this date.
         */
        sessions: number;
    }
}
export interface AvatarCreateParams {
    /**
     * The character name for the avatar.
     */
    name: string;
    /**
     * System prompt defining how the avatar should behave in conversations.
     */
    personality: string;
    /**
     * A HTTPS URL.
     */
    referenceImage: string;
    /**
     * The voice configuration for the avatar.
     */
    voice: AvatarCreateParams.RunwayLivePreset | AvatarCreateParams.Custom;
    /**
     * Optional list of knowledge document IDs to attach to this avatar. Documents
     * provide additional context during conversations.
     */
    documentIds?: Array<string>;
    /**
     * Controls image preprocessing. `optimize` improves the image for better avatar
     * results. `none` uses the image as-is; quality not guaranteed.
     */
    imageProcessing?: 'optimize' | 'none';
    /**
     * Optional opening message that the avatar will say when a session starts.
     */
    startScript?: string;
}
export declare namespace AvatarCreateParams {
    /**
     * A preset voice from the Runway API.
     */
    interface RunwayLivePreset {
        /**
         * The ID of a preset voice. Available voices: `victoria` (Victoria), `vincent`
         * (Vincent), `clara` (Clara), `drew` (Drew), `skye` (Skye), `max` (Max), `morgan`
         * (Morgan), `felix` (Felix), `mia` (Mia), `marcus` (Marcus), `summer` (Summer),
         * `ruby` (Ruby), `aurora` (Aurora), `jasper` (Jasper), `leo` (Leo), `adrian`
         * (Adrian), `nina` (Nina), `emma` (Emma), `blake` (Blake), `david` (David), `maya`
         * (Maya), `nathan` (Nathan), `sam` (Sam), `georgia` (Georgia), `petra` (Petra),
         * `adam` (Adam), `zach` (Zach), `violet` (Violet), `roman` (Roman), `luna` (Luna).
         */
        presetId: 'victoria' | 'vincent' | 'clara' | 'drew' | 'skye' | 'max' | 'morgan' | 'felix' | 'mia' | 'marcus' | 'summer' | 'ruby' | 'aurora' | 'jasper' | 'leo' | 'adrian' | 'nina' | 'emma' | 'blake' | 'david' | 'maya' | 'nathan' | 'sam' | 'georgia' | 'petra' | 'adam' | 'zach' | 'violet' | 'roman' | 'luna';
        type: 'runway-live-preset';
    }
    /**
     * A custom voice created via the Voices API.
     */
    interface Custom {
        /**
         * The ID of a custom voice created via the Voices API.
         */
        id: string;
        type: 'custom';
    }
}
export interface AvatarUpdateParams {
    /**
     * List of knowledge document IDs to attach to this avatar. Replaces all current
     * attachments. Documents provide additional context during conversations.
     */
    documentIds?: Array<string>;
    /**
     * Controls image preprocessing. `optimize` improves the image for better avatar
     * results. `none` uses the image as-is; quality not guaranteed.
     */
    imageProcessing?: 'optimize' | 'none';
    /**
     * The character name for the avatar.
     */
    name?: string;
    /**
     * System prompt defining how the avatar should behave in conversations.
     */
    personality?: string;
    /**
     * A HTTPS URL.
     */
    referenceImage?: string;
    /**
     * Optional opening message that the avatar will say when a session starts. Set to
     * null to clear.
     */
    startScript?: string | null;
    /**
     * The voice configuration for the avatar.
     */
    voice?: AvatarUpdateParams.RunwayLivePreset | AvatarUpdateParams.Custom;
}
export declare namespace AvatarUpdateParams {
    /**
     * A preset voice from the Runway API.
     */
    interface RunwayLivePreset {
        /**
         * The ID of a preset voice. Available voices: `victoria` (Victoria), `vincent`
         * (Vincent), `clara` (Clara), `drew` (Drew), `skye` (Skye), `max` (Max), `morgan`
         * (Morgan), `felix` (Felix), `mia` (Mia), `marcus` (Marcus), `summer` (Summer),
         * `ruby` (Ruby), `aurora` (Aurora), `jasper` (Jasper), `leo` (Leo), `adrian`
         * (Adrian), `nina` (Nina), `emma` (Emma), `blake` (Blake), `david` (David), `maya`
         * (Maya), `nathan` (Nathan), `sam` (Sam), `georgia` (Georgia), `petra` (Petra),
         * `adam` (Adam), `zach` (Zach), `violet` (Violet), `roman` (Roman), `luna` (Luna).
         */
        presetId: 'victoria' | 'vincent' | 'clara' | 'drew' | 'skye' | 'max' | 'morgan' | 'felix' | 'mia' | 'marcus' | 'summer' | 'ruby' | 'aurora' | 'jasper' | 'leo' | 'adrian' | 'nina' | 'emma' | 'blake' | 'david' | 'maya' | 'nathan' | 'sam' | 'georgia' | 'petra' | 'adam' | 'zach' | 'violet' | 'roman' | 'luna';
        type: 'runway-live-preset';
    }
    /**
     * A custom voice created via the Voices API.
     */
    interface Custom {
        /**
         * The ID of a custom voice created via the Voices API.
         */
        id: string;
        type: 'custom';
    }
}
export interface AvatarListParams extends CursorPageParams {
}
export interface AvatarGetUsageParams {
    /**
     * End of the date range in UTC (exclusive). Required.
     */
    endDate: string;
    /**
     * Start of the date range in UTC (inclusive). Required.
     */
    startDate: string;
}
export declare namespace Avatars {
    export { type AvatarCreateResponse as AvatarCreateResponse, type AvatarRetrieveResponse as AvatarRetrieveResponse, type AvatarUpdateResponse as AvatarUpdateResponse, type AvatarListResponse as AvatarListResponse, type AvatarGetUsageResponse as AvatarGetUsageResponse, type AvatarListResponsesCursorPage as AvatarListResponsesCursorPage, type AvatarCreateParams as AvatarCreateParams, type AvatarUpdateParams as AvatarUpdateParams, type AvatarListParams as AvatarListParams, type AvatarGetUsageParams as AvatarGetUsageParams, };
}
//# sourceMappingURL=avatars.d.ts.map