// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../core/resource.mjs";
import { CursorPage } from "../core/pagination.mjs";
import { buildHeaders } from "../internal/headers.mjs";
import { path } from "../internal/utils/path.mjs";
export class AvatarConversations extends APIResource {
    /**
     * Get detailed information about a specific conversation, including the transcript
     * and recording download URL when available. The conversation ID is the same value
     * returned when the realtime session was created.
     */
    retrieve(id, options) {
        return this._client.get(path `/v1/avatar_conversations/${id}`, options);
    }
    /**
     * List realtime avatar conversations for the authenticated user with cursor-based
     * pagination. Each conversation corresponds to a realtime session, and the
     * conversation ID matches the realtime session ID. Pass `avatar` to restrict
     * results to a single avatar.
     */
    list(query, options) {
        return this._client.getAPIList('/v1/avatar_conversations', (CursorPage), {
            query,
            ...options,
        });
    }
    /**
     * Delete a conversation and its associated data.
     */
    delete(id, options) {
        return this._client.delete(path `/v1/avatar_conversations/${id}`, {
            ...options,
            headers: buildHeaders([{ Accept: '*/*' }, options?.headers]),
        });
    }
}
//# sourceMappingURL=avatar-conversations.mjs.map