// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../core/resource.mjs";
import { wrapAsWaitableResource } from "../lib/polling.mjs";
/**
 * These endpoints all kick off tasks to create generations.
 */
export class ImageToVideo extends APIResource {
    /**
     * This endpoint will start a new task to generate a video from an image.
     */
    create(body, options) {
        return wrapAsWaitableResource(this._client)(this._client.post('/v1/image_to_video', { body, ...options }));
    }
}
//# sourceMappingURL=image-to-video.mjs.map