import { APIResource } from "../core/resource.js";
import { RequestOptions } from "../internal/request-options.js";
import { APIPromiseWithAwaitableTask } from "../lib/polling.js";
/**
 * These endpoints all kick off tasks to create generations.
 */
export declare class SoundEffect extends APIResource {
    /**
     * This endpoint will start a new task to generate sound effects from a text
     * description.
     */
    create(body: SoundEffectCreateParams, options?: RequestOptions): APIPromiseWithAwaitableTask<SoundEffectCreateResponse>;
}
export interface SoundEffectCreateResponse {
    /**
     * The ID of the task that was created. Use this to retrieve the task later.
     */
    id: string;
}
export interface SoundEffectCreateParams {
    model: 'eleven_text_to_sound_v2';
    /**
     * A text description of the sound effect to generate.
     */
    promptText: string;
    /**
     * The duration of the sound effect in seconds, between 0.5 and 30 seconds. If not
     * provided, the duration will be determined automatically based on the text
     * description.
     */
    duration?: number;
    /**
     * Whether the output sound effect should be designed to loop seamlessly.
     */
    loop?: boolean;
}
export declare namespace SoundEffect {
    export { type SoundEffectCreateResponse as SoundEffectCreateResponse, type SoundEffectCreateParams as SoundEffectCreateParams, };
}
//# sourceMappingURL=sound-effect.d.ts.map