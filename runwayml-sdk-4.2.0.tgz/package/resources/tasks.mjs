// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../core/resource.mjs";
import { buildHeaders } from "../internal/headers.mjs";
import { path } from "../internal/utils/path.mjs";
import { wrapAsWaitableResource } from "../lib/polling.mjs";
/**
 * Endpoints for managing tasks that have been submitted.
 */
export class Tasks extends APIResource {
    /**
     * Return details about a task. Consumers of this API should not expect updates
     * more frequent than once every five seconds for a given task.
     */
    retrieve(id, options) {
        return wrapAsWaitableResource(this._client)(this._client.get(path `/v1/tasks/${id}`, options), true);
    }
    /**
     * Tasks that are running, pending, or throttled can be canceled by invoking this
     * method. Invoking this method for other tasks will delete them.
     *
     * The output data associated with a deleted task will be deleted from persistent
     * storage in accordance with our data retention policy. Aborted and deleted tasks
     * will not be able to be fetched again in the future.
     */
    delete(id, options) {
        return this._client.delete(path `/v1/tasks/${id}`, {
            ...options,
            headers: buildHeaders([{ Accept: '*/*' }, options?.headers]),
        });
    }
}
//# sourceMappingURL=tasks.mjs.map