"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.VoiceIsolation = void 0;
const resource_1 = require("../core/resource.js");
const polling_1 = require("../lib/polling.js");
/**
 * These endpoints all kick off tasks to create generations.
 */
class VoiceIsolation extends resource_1.APIResource {
    /**
     * This endpoint will start a new task to isolate the voice from the background
     * audio. Audio duration must be greater than 4.6 seconds and less than 3600
     * seconds.
     *
     * @example
     * ```ts
     * const voiceIsolation = await client.voiceIsolation.create({
     *   audioUri: 'https://example.com/audio.mp3',
     *   model: 'eleven_voice_isolation',
     * });
     * ```
     */
    create(body, options) {
        return (0, polling_1.wrapAsWaitableResource)(this._client)(this._client.post('/v1/voice_isolation', { body, ...options }));
    }
}
exports.VoiceIsolation = VoiceIsolation;
//# sourceMappingURL=voice-isolation.js.map