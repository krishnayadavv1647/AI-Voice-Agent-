"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.Documents = void 0;
const resource_1 = require("../core/resource.js");
const pagination_1 = require("../core/pagination.js");
const headers_1 = require("../internal/headers.js");
const path_1 = require("../internal/utils/path.js");
class Documents extends resource_1.APIResource {
    /**
     * Create a new knowledge document. Documents can be attached to avatars to provide
     * additional context during conversations.
     *
     * @example
     * ```ts
     * const document = await client.documents.create({
     *   content:
     *     '# Product FAQ\n\n## What is your return policy?\n\nWe offer a 30-day return policy...',
     *   name: 'Product FAQ',
     * });
     * ```
     */
    create(body, options) {
        return this._client.post('/v1/documents', { body, ...options });
    }
    /**
     * Get details of a specific knowledge document.
     *
     * @example
     * ```ts
     * const document = await client.documents.retrieve(
     *   '182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e',
     * );
     * ```
     */
    retrieve(id, options) {
        return this._client.get((0, path_1.path) `/v1/documents/${id}`, options);
    }
    /**
     * Update a knowledge document. At least one of `name` or `content` must be
     * provided.
     *
     * @example
     * ```ts
     * await client.documents.update(
     *   '182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e',
     * );
     * ```
     */
    update(id, body = {}, options) {
        return this._client.patch((0, path_1.path) `/v1/documents/${id}`, {
            body,
            ...options,
            headers: (0, headers_1.buildHeaders)([{ Accept: '*/*' }, options?.headers]),
        });
    }
    /**
     * List knowledge documents for the authenticated user with cursor-based
     * pagination.
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const documentListResponse of client.documents.list(
     *   {
     *     limit: 1,
     *     order: 'asc',
     *     sort: 'createdAt',
     *   },
     * )) {
     *   // ...
     * }
     * ```
     */
    list(query, options) {
        return this._client.getAPIList('/v1/documents', (pagination_1.CursorPage), { query, ...options });
    }
    /**
     * Delete a knowledge document. This also removes it from all avatars it was
     * attached to.
     *
     * @example
     * ```ts
     * await client.documents.delete(
     *   '182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e',
     * );
     * ```
     */
    delete(id, options) {
        return this._client.delete((0, path_1.path) `/v1/documents/${id}`, {
            ...options,
            headers: (0, headers_1.buildHeaders)([{ Accept: '*/*' }, options?.headers]),
        });
    }
}
exports.Documents = Documents;
//# sourceMappingURL=documents.js.map