// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../core/resource.mjs";
import { wrapAsWaitableResource } from "../lib/polling.mjs";
/**
 * These endpoints all kick off tasks to create generations.
 */
export class VideoToVideo extends APIResource {
    /**
     * This endpoint will start a new task to generate a video from a video.
     *
     * @example
     * ```ts
     * const videoToVideo = await client.videoToVideo.create({
     *   model: 'aleph2',
     *   videoUri: 'https://example.com/video.mp4',
     * });
     * ```
     */
    create(body, options) {
        return wrapAsWaitableResource(this._client)(this._client.post('/v1/video_to_video', { body, ...options }));
    }
}
//# sourceMappingURL=video-to-video.mjs.map