// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { wrapAsWaitableResource } from "../lib/polling.mjs";
import { APIResource } from "../core/resource.mjs";
/**
 * These endpoints all kick off tasks to create generations.
 */
export class SpeechToSpeech extends APIResource {
    /**
     * This endpoint will start a new task to convert speech from one voice to another
     * in audio or video.
     */
    create(body, options) {
        return wrapAsWaitableResource(this._client)(this._client.post('/v1/speech_to_speech', { body, ...options }));
    }
}
//# sourceMappingURL=speech-to-speech.mjs.map