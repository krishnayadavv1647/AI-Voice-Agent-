"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.TextToImage = void 0;
const resource_1 = require("../core/resource.js");
const polling_1 = require("../lib/polling.js");
/**
 * These endpoints all kick off tasks to create generations.
 */
class TextToImage extends resource_1.APIResource {
    /**
     * This endpoint will start a new task to generate images from text and/or image(s)
     */
    create(body, options) {
        return (0, polling_1.wrapAsWaitableResource)(this._client)(this._client.post('/v1/text_to_image', { body, ...options }));
    }
}
exports.TextToImage = TextToImage;
//# sourceMappingURL=text-to-image.js.map