// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../core/resource.mjs";
import { wrapAsWaitableResource } from "../lib/polling.mjs";
/**
 * These endpoints all kick off tasks to create generations.
 */
export class SoundEffect extends APIResource {
    /**
     * This endpoint will start a new task to generate sound effects from a text
     * description.
     */
    create(body, options) {
        return wrapAsWaitableResource(this._client)(this._client.post('/v1/sound_effect', { body, ...options }));
    }
}
//# sourceMappingURL=sound-effect.mjs.map