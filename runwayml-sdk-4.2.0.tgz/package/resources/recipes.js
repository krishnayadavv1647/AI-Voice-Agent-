"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.Recipes = void 0;
const resource_1 = require("../core/resource.js");
const polling_1 = require("../lib/polling.js");
class Recipes extends resource_1.APIResource {
    /**
     * Generate a polished marketing stock image from a text brief and optional brand
     * logo image.
     */
    marketingStockImage(body, options) {
        return (0, polling_1.wrapAsWaitableResource)(this._client)(this._client.post('/v1/recipes/marketing_stock_image', { body, ...options }));
    }
    /**
     * Generate a multi-cut video from a story prompt (auto mode) or a custom shot list
     * (custom mode).
     */
    multiShotVideo(body, options) {
        return (0, polling_1.wrapAsWaitableResource)(this._client)(this._client.post('/v1/recipes/multi_shot_video', { body, ...options }));
    }
    /**
     * Generate a cinematic product ad from product images, optional style references,
     * product info, and creative direction.
     */
    productAd(body, options) {
        return (0, polling_1.wrapAsWaitableResource)(this._client)(this._client.post('/v1/recipes/product_ad', { body, ...options }));
    }
    /**
     * Generate four fashion campaign images from a product image and style brief.
     */
    productCampaignImage(body, options) {
        return (0, polling_1.wrapAsWaitableResource)(this._client)(this._client.post('/v1/recipes/product_campaign_image', { body, ...options }));
    }
    /**
     * Replace the product in a reference video with a new product, preserving camera
     * motion, lighting, and scene composition.
     */
    productSwap(body, options) {
        return (0, polling_1.wrapAsWaitableResource)(this._client)(this._client.post('/v1/recipes/product_swap', { body, ...options }));
    }
    /**
     * Generate a vertical user-generated content ad from a character image, product
     * image, product details, and optional creative direction.
     */
    productUgc(body, options) {
        return (0, polling_1.wrapAsWaitableResource)(this._client)(this._client.post('/v1/recipes/product_ugc', { body, ...options }));
    }
}
exports.Recipes = Recipes;
//# sourceMappingURL=recipes.js.map