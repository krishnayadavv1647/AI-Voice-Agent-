"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.Voices = void 0;
const resource_1 = require("../core/resource.js");
const pagination_1 = require("../core/pagination.js");
const headers_1 = require("../internal/headers.js");
const path_1 = require("../internal/utils/path.js");
class Voices extends resource_1.APIResource {
    /**
     * Create a custom voice from a text description, or clone a voice from an audio
     * sample.
     */
    create(body, options) {
        return this._client.post('/v1/voices', { body, ...options });
    }
    /**
     * Get details about a specific custom voice.
     */
    retrieve(id, options) {
        return this._client.get((0, path_1.path) `/v1/voices/${id}`, options);
    }
    /**
     * Update the name and/or description of a custom voice.
     */
    update(id, body = {}, options) {
        return this._client.patch((0, path_1.path) `/v1/voices/${id}`, { body, ...options });
    }
    /**
     * List custom voices for the authenticated organization with cursor-based
     * pagination.
     */
    list(query, options) {
        return this._client.getAPIList('/v1/voices', (pagination_1.CursorPage), { query, ...options });
    }
    /**
     * Delete a custom voice.
     */
    delete(id, options) {
        return this._client.delete((0, path_1.path) `/v1/voices/${id}`, {
            ...options,
            headers: (0, headers_1.buildHeaders)([{ Accept: '*/*' }, options?.headers]),
        });
    }
    /**
     * Generate a short audio preview of a voice from a text description. Use this to
     * audition a voice before creating it.
     */
    preview(body, options) {
        return this._client.post('/v1/voices/preview', { body, ...options });
    }
}
exports.Voices = Voices;
//# sourceMappingURL=voices.js.map