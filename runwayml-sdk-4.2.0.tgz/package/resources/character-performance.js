"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.CharacterPerformance = void 0;
const resource_1 = require("../core/resource.js");
const polling_1 = require("../lib/polling.js");
/**
 * These endpoints all kick off tasks to create generations.
 */
class CharacterPerformance extends resource_1.APIResource {
    /**
     * This endpoint will start a new task to control a character's facial expressions
     * and body movements using a reference video.
     *
     * @example
     * ```ts
     * const characterPerformance =
     *   await client.characterPerformance.create({
     *     character: {
     *       type: 'image',
     *       uri: 'https://example.com/file',
     *     },
     *     model: 'act_two',
     *     reference: {
     *       type: 'video',
     *       uri: 'https://example.com/reference-performance.mp4',
     *     },
     *   });
     * ```
     */
    create(body, options) {
        return (0, polling_1.wrapAsWaitableResource)(this._client)(this._client.post('/v1/character_performance', { body, ...options }));
    }
}
exports.CharacterPerformance = CharacterPerformance;
//# sourceMappingURL=character-performance.js.map