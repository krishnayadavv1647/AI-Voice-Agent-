import { APIResource } from "../core/resource.js";
import { RequestOptions } from "../internal/request-options.js";
import { APIPromiseWithAwaitableWorkflowInvocation } from "../lib/polling.js";
export declare class WorkflowInvocations extends APIResource {
    /**
     * Return details about a workflow invocation. Consumers of this API should not
     * expect updates more frequent than once every five seconds for a given workflow
     * invocation.
     */
    retrieve(id: string, options?: RequestOptions): APIPromiseWithAwaitableWorkflowInvocation<WorkflowInvocationRetrieveResponse>;
}
/**
 * A pending workflow invocation
 */
export type WorkflowInvocationRetrieveResponse = WorkflowInvocationRetrieveResponse.Pending | WorkflowInvocationRetrieveResponse.Throttled | WorkflowInvocationRetrieveResponse.Cancelled | WorkflowInvocationRetrieveResponse.Running | WorkflowInvocationRetrieveResponse.Failed | WorkflowInvocationRetrieveResponse.Succeeded;
export declare namespace WorkflowInvocationRetrieveResponse {
    /**
     * A pending workflow invocation
     */
    interface Pending {
        /**
         * The ID of the workflow invocation being returned.
         */
        id: string;
        /**
         * The timestamp that the workflow invocation was submitted at.
         */
        createdAt: string;
        status: 'PENDING';
    }
    /**
     * A throttled workflow invocation
     */
    interface Throttled {
        /**
         * The ID of the workflow invocation being returned.
         */
        id: string;
        /**
         * The timestamp that the workflow invocation was submitted at.
         */
        createdAt: string;
        status: 'THROTTLED';
    }
    /**
     * A cancelled or deleted workflow invocation
     */
    interface Cancelled {
        /**
         * The ID of the workflow invocation being returned.
         */
        id: string;
        /**
         * The timestamp that the workflow invocation was submitted at.
         */
        createdAt: string;
        status: 'CANCELLED';
    }
    /**
     * A running workflow invocation
     */
    interface Running {
        /**
         * The ID of the workflow invocation being returned.
         */
        id: string;
        /**
         * The timestamp that the workflow invocation was submitted at.
         */
        createdAt: string;
        /**
         * A record mapping workflow node IDs to arrays of output URLs for nodes that have
         * already completed. This allows streaming partial results while the workflow is
         * still running.
         */
        output: {
            [key: string]: Array<string>;
        };
        /**
         * A number between 0 and 1 representing the overall workflow execution progress.
         */
        progress: number;
        status: 'RUNNING';
        /**
         * A record mapping workflow node IDs to their error details. Only present when one
         * or more nodes have errored.
         */
        nodeErrors?: {
            [key: string]: Running.NodeErrors;
        };
    }
    namespace Running {
        interface NodeErrors {
            /**
             * A human-readable description of the node error.
             */
            message: string;
            /**
             * The human-readable name of the node that errored.
             */
            nodeName?: string;
        }
    }
    /**
     * A failed workflow invocation
     */
    interface Failed {
        /**
         * The ID of the workflow invocation being returned.
         */
        id: string;
        /**
         * The timestamp that the workflow invocation was submitted at.
         */
        createdAt: string;
        /**
         * A human-friendly reason for the failure. We do not recommend returning this to
         * users directly without adding context.
         */
        failure: string;
        status: 'FAILED';
        /**
         * A machine-readable error code for the failure. See
         * https://docs.dev.runwayml.com/errors/task-failures/ for more information.
         */
        failureCode?: string;
        /**
         * A record mapping workflow node IDs to their error details. Only present when one
         * or more nodes have errored.
         */
        nodeErrors?: {
            [key: string]: Failed.NodeErrors;
        };
    }
    namespace Failed {
        interface NodeErrors {
            /**
             * A human-readable description of the node error.
             */
            message: string;
            /**
             * The human-readable name of the node that errored.
             */
            nodeName?: string;
        }
    }
    /**
     * A succeeded workflow invocation
     */
    interface Succeeded {
        /**
         * The ID of the workflow invocation being returned.
         */
        id: string;
        /**
         * The timestamp that the workflow invocation was submitted at.
         */
        createdAt: string;
        /**
         * A record mapping workflow node IDs to arrays of output URLs. Each key is the
         * UUID of a workflow node that produced output, and each value is an array of URLs
         * for that node's artifacts. These URLs will expire within 24-48 hours; fetch the
         * invocation again to get fresh URLs. It is expected that you download the assets
         * at these URLs and store them in your own storage system.
         */
        output: {
            [key: string]: Array<string>;
        };
        status: 'SUCCEEDED';
        /**
         * A record mapping workflow node IDs to their error details. Even when the overall
         * workflow succeeds, individual nodes may have encountered non-fatal errors. Only
         * present when one or more nodes have errored.
         */
        nodeErrors?: {
            [key: string]: Succeeded.NodeErrors;
        };
    }
    namespace Succeeded {
        interface NodeErrors {
            /**
             * A human-readable description of the node error.
             */
            message: string;
            /**
             * The human-readable name of the node that errored.
             */
            nodeName?: string;
        }
    }
}
export declare namespace WorkflowInvocations {
    export { type WorkflowInvocationRetrieveResponse as WorkflowInvocationRetrieveResponse };
}
//# sourceMappingURL=workflow-invocations.d.ts.map