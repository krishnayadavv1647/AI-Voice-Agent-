// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../core/resource.mjs";
import { wrapAsWaitableResource } from "../lib/polling.mjs";
/**
 * These endpoints all kick off tasks to create generations.
 */
export class VoiceDubbing extends APIResource {
    /**
     * This endpoint will start a new task to dub audio content to a target language.
     *
     * @example
     * ```ts
     * const voiceDubbing = await client.voiceDubbing.create({
     *   audioUri: 'https://example.com/audio.mp3',
     *   model: 'eleven_voice_dubbing',
     *   targetLang: 'en',
     * });
     * ```
     */
    create(body, options) {
        return wrapAsWaitableResource(this._client)(this._client.post('/v1/voice_dubbing', { body, ...options }));
    }
}
//# sourceMappingURL=voice-dubbing.mjs.map