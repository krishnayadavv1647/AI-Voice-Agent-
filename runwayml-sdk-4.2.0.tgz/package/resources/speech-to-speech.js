"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SpeechToSpeech = void 0;
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
const polling_1 = require("../lib/polling.js");
const resource_1 = require("../core/resource.js");
/**
 * These endpoints all kick off tasks to create generations.
 */
class SpeechToSpeech extends resource_1.APIResource {
    /**
     * This endpoint will start a new task to convert speech from one voice to another
     * in audio or video.
     */
    create(body, options) {
        return (0, polling_1.wrapAsWaitableResource)(this._client)(this._client.post('/v1/speech_to_speech', { body, ...options }));
    }
}
exports.SpeechToSpeech = SpeechToSpeech;
//# sourceMappingURL=speech-to-speech.js.map