// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../core/resource.mjs";
import { wrapAsWaitableResource } from "../lib/polling.mjs";
/**
 * These endpoints all kick off tasks to create generations.
 */
export class TextToSpeech extends APIResource {
    /**
     * This endpoint will start a new task to generate speech from text.
     */
    create(body, options) {
        return wrapAsWaitableResource(this._client)(this._client.post('/v1/text_to_speech', { body, ...options }));
    }
}
//# sourceMappingURL=text-to-speech.mjs.map