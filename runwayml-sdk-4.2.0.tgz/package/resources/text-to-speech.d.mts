import { APIResource } from "../core/resource.mjs";
import { RequestOptions } from "../internal/request-options.mjs";
import { APIPromiseWithAwaitableTask } from "../lib/polling.mjs";
/**
 * These endpoints all kick off tasks to create generations.
 */
export declare class TextToSpeech extends APIResource {
    /**
     * This endpoint will start a new task to generate speech from text.
     */
    create(body: TextToSpeechCreateParams, options?: RequestOptions): APIPromiseWithAwaitableTask<TextToSpeechCreateResponse>;
}
export interface TextToSpeechCreateResponse {
    /**
     * The ID of the task that was created. Use this to retrieve the task later.
     */
    id: string;
}
export interface TextToSpeechCreateParams {
    model: 'eleven_multilingual_v2';
    /**
     * A non-empty string up to 1000 characters (measured in UTF-16 code units). This
     * should describe in detail what should appear in the output.
     */
    promptText: string;
    /**
     * A voice preset from the RunwayML API.
     */
    voice: TextToSpeechCreateParams.Voice;
}
export declare namespace TextToSpeechCreateParams {
    /**
     * A voice preset from the RunwayML API.
     */
    interface Voice {
        /**
         * The preset voice ID to use for the generated speech.
         */
        presetId: 'Maya' | 'Arjun' | 'Serene' | 'Bernard' | 'Billy' | 'Mark' | 'Clint' | 'Mabel' | 'Chad' | 'Leslie' | 'Eleanor' | 'Elias' | 'Elliot' | 'Grungle' | 'Brodie' | 'Sandra' | 'Kirk' | 'Kylie' | 'Lara' | 'Lisa' | 'Malachi' | 'Marlene' | 'Martin' | 'Miriam' | 'Monster' | 'Paula' | 'Pip' | 'Rusty' | 'Ragnar' | 'Xylar' | 'Maggie' | 'Jack' | 'Katie' | 'Noah' | 'James' | 'Rina' | 'Ella' | 'Mariah' | 'Frank' | 'Claudia' | 'Niki' | 'Vincent' | 'Kendrick' | 'Myrna' | 'Tom' | 'Wanda' | 'Benjamin' | 'Kiana' | 'Rachel';
        type: 'runway-preset';
    }
}
export declare namespace TextToSpeech {
    export { type TextToSpeechCreateResponse as TextToSpeechCreateResponse, type TextToSpeechCreateParams as TextToSpeechCreateParams, };
}
//# sourceMappingURL=text-to-speech.d.mts.map