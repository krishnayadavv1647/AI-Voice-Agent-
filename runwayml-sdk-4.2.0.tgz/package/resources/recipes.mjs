// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../core/resource.mjs";
import { wrapAsWaitableResource } from "../lib/polling.mjs";
export class Recipes extends APIResource {
    /**
     * Generate a polished marketing stock image from a text brief and optional brand
     * logo image.
     */
    marketingStockImage(body, options) {
        return wrapAsWaitableResource(this._client)(this._client.post('/v1/recipes/marketing_stock_image', { body, ...options }));
    }
    /**
     * Generate a multi-cut video from a story prompt (auto mode) or a custom shot list
     * (custom mode).
     */
    multiShotVideo(body, options) {
        return wrapAsWaitableResource(this._client)(this._client.post('/v1/recipes/multi_shot_video', { body, ...options }));
    }
    /**
     * Generate a cinematic product ad from product images, optional style references,
     * product info, and creative direction.
     */
    productAd(body, options) {
        return wrapAsWaitableResource(this._client)(this._client.post('/v1/recipes/product_ad', { body, ...options }));
    }
    /**
     * Generate four fashion campaign images from a product image and style brief.
     */
    productCampaignImage(body, options) {
        return wrapAsWaitableResource(this._client)(this._client.post('/v1/recipes/product_campaign_image', { body, ...options }));
    }
    /**
     * Replace the product in a reference video with a new product, preserving camera
     * motion, lighting, and scene composition.
     */
    productSwap(body, options) {
        return wrapAsWaitableResource(this._client)(this._client.post('/v1/recipes/product_swap', { body, ...options }));
    }
    /**
     * Generate a vertical user-generated content ad from a character image, product
     * image, product details, and optional creative direction.
     */
    productUgc(body, options) {
        return wrapAsWaitableResource(this._client)(this._client.post('/v1/recipes/product_ugc', { body, ...options }));
    }
}
//# sourceMappingURL=recipes.mjs.map