"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.Tasks = void 0;
const resource_1 = require("../core/resource.js");
const headers_1 = require("../internal/headers.js");
const path_1 = require("../internal/utils/path.js");
const polling_1 = require("../lib/polling.js");
/**
 * Endpoints for managing tasks that have been submitted.
 */
class Tasks extends resource_1.APIResource {
    /**
     * Return details about a task. Consumers of this API should not expect updates
     * more frequent than once every five seconds for a given task.
     */
    retrieve(id, options) {
        return (0, polling_1.wrapAsWaitableResource)(this._client)(this._client.get((0, path_1.path) `/v1/tasks/${id}`, options), true);
    }
    /**
     * Tasks that are running, pending, or throttled can be canceled by invoking this
     * method. Invoking this method for other tasks will delete them.
     *
     * The output data associated with a deleted task will be deleted from persistent
     * storage in accordance with our data retention policy. Aborted and deleted tasks
     * will not be able to be fetched again in the future.
     */
    delete(id, options) {
        return this._client.delete((0, path_1.path) `/v1/tasks/${id}`, {
            ...options,
            headers: (0, headers_1.buildHeaders)([{ Accept: '*/*' }, options?.headers]),
        });
    }
}
exports.Tasks = Tasks;
//# sourceMappingURL=tasks.js.map