// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../core/resource.mjs";
import { wrapAsWaitableResource } from "../lib/polling.mjs";
/**
 * These endpoints all kick off tasks to create generations.
 */
export class VoiceIsolation extends APIResource {
    /**
     * This endpoint will start a new task to isolate the voice from the background
     * audio. Audio duration must be greater than 4.6 seconds and less than 3600
     * seconds.
     *
     * @example
     * ```ts
     * const voiceIsolation = await client.voiceIsolation.create({
     *   audioUri: 'https://example.com/audio.mp3',
     *   model: 'eleven_voice_isolation',
     * });
     * ```
     */
    create(body, options) {
        return wrapAsWaitableResource(this._client)(this._client.post('/v1/voice_isolation', { body, ...options }));
    }
}
//# sourceMappingURL=voice-isolation.mjs.map