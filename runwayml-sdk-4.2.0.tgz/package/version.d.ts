export declare const VERSION = "4.2.0";
//# sourceMappingURL=version.d.ts.map