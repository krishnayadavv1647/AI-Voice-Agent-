import type { RunwayML } from "../client.js";
export declare abstract class APIResource {
    protected _client: RunwayML;
    constructor(client: RunwayML);
}
//# sourceMappingURL=resource.d.ts.map