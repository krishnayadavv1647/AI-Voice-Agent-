import type { RunwayML } from "../client.mjs";
export declare abstract class APIResource {
    protected _client: RunwayML;
    constructor(client: RunwayML);
}
//# sourceMappingURL=resource.d.mts.map