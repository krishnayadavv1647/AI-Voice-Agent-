// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

import type { RequestInit, RequestInfo, BodyInit } from './internal/builtin-types';
import type { HTTPMethod, PromiseOrValue, MergedRequestInit, FinalizedRequestInit } from './internal/types';
import { uuid4 } from './internal/utils/uuid';
import { validatePositiveInteger, isAbsoluteURL, safeJSON } from './internal/utils/values';
import { sleep } from './internal/utils/sleep';
export type { Logger, LogLevel } from './internal/utils/log';
import { castToError, isAbortError } from './internal/errors';
import type { APIResponseProps } from './internal/parse';
import { getPlatformHeaders } from './internal/detect-platform';
import * as Shims from './internal/shims';
import * as Opts from './internal/request-options';
import { stringifyQuery } from './internal/utils/query';
import { VERSION } from './version';
import * as Errors from './core/error';
import * as Pagination from './core/pagination';
import { AbstractPage, type CursorPageParams, CursorPageResponse } from './core/pagination';
import * as UploadsCore from './core/uploads';
import * as API from './resources/index';
import { APIPromise } from './core/api-promise';
import {
  AvatarConversationListParams,
  AvatarConversationListResponse,
  AvatarConversationListResponsesCursorPage,
  AvatarConversationRetrieveResponse,
  AvatarConversations,
} from './resources/avatar-conversations';
import { AvatarVideoCreateParams, AvatarVideoCreateResponse, AvatarVideos } from './resources/avatar-videos';
import {
  AvatarCreateParams,
  AvatarCreateResponse,
  AvatarGetUsageParams,
  AvatarGetUsageResponse,
  AvatarListParams,
  AvatarListResponse,
  AvatarListResponsesCursorPage,
  AvatarRetrieveResponse,
  AvatarUpdateParams,
  AvatarUpdateResponse,
  Avatars,
} from './resources/avatars';
import {
  CharacterPerformance,
  CharacterPerformanceCreateParams,
  CharacterPerformanceCreateResponse,
} from './resources/character-performance';
import {
  DocumentCreateParams,
  DocumentCreateResponse,
  DocumentListParams,
  DocumentListResponse,
  DocumentListResponsesCursorPage,
  DocumentRetrieveResponse,
  DocumentUpdateParams,
  Documents,
} from './resources/documents';
import {
  ImageToVideo,
  ImageToVideoCreateParams,
  ImageToVideoCreateResponse,
} from './resources/image-to-video';
import {
  ImageUpscale,
  ImageUpscaleCreateParams,
  ImageUpscaleCreateResponse,
} from './resources/image-upscale';
import {
  Organization,
  OrganizationRetrieveResponse,
  OrganizationRetrieveUsageParams,
  OrganizationRetrieveUsageResponse,
} from './resources/organization';
import {
  RealtimeSessionCreateParams,
  RealtimeSessionCreateResponse,
  RealtimeSessionRetrieveResponse,
  RealtimeSessions,
} from './resources/realtime-sessions';
import {
  RecipeMarketingStockImageParams,
  RecipeMarketingStockImageResponse,
  RecipeMultiShotVideoParams,
  RecipeMultiShotVideoResponse,
  RecipeProductAdParams,
  RecipeProductAdResponse,
  RecipeProductCampaignImageParams,
  RecipeProductCampaignImageResponse,
  RecipeProductSwapParams,
  RecipeProductSwapResponse,
  RecipeProductUgcParams,
  RecipeProductUgcResponse,
  Recipes,
} from './resources/recipes';
import { SoundEffect, SoundEffectCreateParams, SoundEffectCreateResponse } from './resources/sound-effect';
import {
  SpeechToSpeech,
  SpeechToSpeechCreateParams,
  SpeechToSpeechCreateResponse,
} from './resources/speech-to-speech';
import { TaskRetrieveResponse, Tasks } from './resources/tasks';
import { TextToImage, TextToImageCreateParams, TextToImageCreateResponse } from './resources/text-to-image';
import {
  TextToSpeech,
  TextToSpeechCreateParams,
  TextToSpeechCreateResponse,
} from './resources/text-to-speech';
import { TextToVideo, TextToVideoCreateParams, TextToVideoCreateResponse } from './resources/text-to-video';
import {
  VideoToVideo,
  VideoToVideoCreateParams,
  VideoToVideoCreateResponse,
} from './resources/video-to-video';
import {
  VoiceDubbing,
  VoiceDubbingCreateParams,
  VoiceDubbingCreateResponse,
} from './resources/voice-dubbing';
import {
  VoiceIsolation,
  VoiceIsolationCreateParams,
  VoiceIsolationCreateResponse,
} from './resources/voice-isolation';
import { Uploads, UploadsCreateEphemeralParams, UploadCreateEphemeralResponse } from './resources/uploads';
import {
  VoiceCreateParams,
  VoiceCreateResponse,
  VoiceListParams,
  VoiceListResponse,
  VoiceListResponsesCursorPage,
  VoicePreviewParams,
  VoicePreviewResponse,
  VoiceRetrieveResponse,
  VoiceUpdateParams,
  VoiceUpdateResponse,
  Voices,
} from './resources/voices';
import { WorkflowInvocationRetrieveResponse, WorkflowInvocations } from './resources/workflow-invocations';
import {
  WorkflowListResponse,
  WorkflowRetrieveResponse,
  WorkflowRunParams,
  WorkflowRunResponse,
  Workflows,
} from './resources/workflows';
import { type Fetch } from './internal/builtin-types';
import { isRunningInBrowser } from './internal/detect-platform';
import { HeadersLike, NullableHeaders, buildHeaders } from './internal/headers';
import { FinalRequestOptions, RequestOptions } from './internal/request-options';
import { readEnv } from './internal/utils/env';
import {
  type LogLevel,
  type Logger,
  formatRequestDetails,
  loggerFor,
  parseLogLevel,
} from './internal/utils/log';
import { isEmptyObj } from './internal/utils/values';

export interface ClientOptions {
  /**
   * Defaults to process.env['RUNWAYML_API_SECRET'].
   */
  apiKey?: string | undefined;

  runwayVersion?: string | undefined;

  /**
   * Override the default base URL for the API, e.g., "https://api.example.com/v2/"
   *
   * Defaults to process.env['RUNWAYML_BASE_URL'].
   */
  baseURL?: string | null | undefined;

  /**
   * The maximum amount of time (in milliseconds) that the client should wait for a response
   * from the server before timing out a single request.
   *
   * Note that request timeouts are retried by default, so in a worst-case scenario you may wait
   * much longer than this timeout before the promise succeeds or fails.
   *
   * @unit milliseconds
   */
  timeout?: number | undefined;
  /**
   * Additional `RequestInit` options to be passed to `fetch` calls.
   * Properties will be overridden by per-request `fetchOptions`.
   */
  fetchOptions?: MergedRequestInit | undefined;

  /**
   * Specify a custom `fetch` function implementation.
   *
   * If not provided, we expect that `fetch` is defined globally.
   */
  fetch?: Fetch | undefined;

  /**
   * The maximum number of times that the client will retry a request in case of a
   * temporary failure, like a network error or a 5XX error from the server.
   *
   * @default 2
   */
  maxRetries?: number | undefined;

  /**
   * Default headers to include with every request to the API.
   *
   * These can be removed in individual requests by explicitly setting the
   * header to `null` in request options.
   */
  defaultHeaders?: HeadersLike | undefined;

  /**
   * Default query parameters to include with every request to the API.
   *
   * These can be removed in individual requests by explicitly setting the
   * param to `undefined` in request options.
   */
  defaultQuery?: Record<string, string | undefined> | undefined;

  /**
   * Set the log level.
   *
   * Defaults to process.env['RUNWAYML_LOG'] or 'warn' if it isn't set.
   */
  logLevel?: LogLevel | undefined;

  /**
   * Set the logger.
   *
   * Defaults to globalThis.console.
   */
  logger?: Logger | undefined;
}

/**
 * API Client for interfacing with the RunwayML API.
 */
export class RunwayML {
  apiKey: string;
  runwayVersion: string;

  baseURL: string;
  maxRetries: number;
  timeout: number;
  logger: Logger;
  logLevel: LogLevel | undefined;
  fetchOptions: MergedRequestInit | undefined;

  private fetch: Fetch;
  #encoder: Opts.RequestEncoder;
  protected idempotencyHeader?: string;
  private _options: ClientOptions;

  /**
   * API Client for interfacing with the RunwayML API.
   *
   * @param {string | undefined} [opts.apiKey=process.env['RUNWAYML_API_SECRET'] ?? undefined]
   * @param {string | undefined} [opts.runwayVersion=2024-11-06]
   * @param {string} [opts.baseURL=process.env['RUNWAYML_BASE_URL'] ?? https://api.dev.runwayml.com] - Override the default base URL for the API.
   * @param {number} [opts.timeout=1 minute] - The maximum amount of time (in milliseconds) the client will wait for a response before timing out.
   * @param {MergedRequestInit} [opts.fetchOptions] - Additional `RequestInit` options to be passed to `fetch` calls.
   * @param {Fetch} [opts.fetch] - Specify a custom `fetch` function implementation.
   * @param {number} [opts.maxRetries=2] - The maximum number of times the client will retry a request.
   * @param {HeadersLike} opts.defaultHeaders - Default headers to include with every request to the API.
   * @param {Record<string, string | undefined>} opts.defaultQuery - Default query parameters to include with every request to the API.
   */
  constructor({
    baseURL = readEnv('RUNWAYML_BASE_URL'),
    apiKey = readEnv('RUNWAYML_API_SECRET'),
    runwayVersion = '2024-11-06',
    ...opts
  }: ClientOptions = {}) {
    if (apiKey === undefined) {
      throw new Errors.RunwayMLError(
        "The RUNWAYML_API_SECRET environment variable is missing or empty; either provide it, or instantiate the RunwayML client with an apiKey option, like new RunwayML({ apiKey: 'My API Key' }).",
      );
    }

    const options: ClientOptions = {
      apiKey,
      runwayVersion,
      ...opts,
      baseURL: baseURL || `https://api.dev.runwayml.com`,
    };

    if (isRunningInBrowser()) {
      throw new Errors.RunwayMLError(
        "It looks like you're running in a browser-like environment, which is disabled to protect your secret API credentials from attackers. If you have a strong business need for client-side use of this API, please open a GitHub issue with your use-case and security mitigations.",
      );
    }

    this.baseURL = options.baseURL!;
    this.timeout = options.timeout ?? RunwayML.DEFAULT_TIMEOUT /* 1 minute */;
    this.logger = options.logger ?? console;
    const defaultLogLevel = 'warn';
    // Set default logLevel early so that we can log a warning in parseLogLevel.
    this.logLevel = defaultLogLevel;
    this.logLevel =
      parseLogLevel(options.logLevel, 'ClientOptions.logLevel', this) ??
      parseLogLevel(readEnv('RUNWAYML_LOG'), "process.env['RUNWAYML_LOG']", this) ??
      defaultLogLevel;
    this.fetchOptions = options.fetchOptions;
    this.maxRetries = options.maxRetries ?? 2;
    this.fetch = options.fetch ?? Shims.getDefaultFetch();
    this.#encoder = Opts.FallbackEncoder;

    const customHeadersEnv = readEnv('RUNWAYML_CUSTOM_HEADERS');
    if (customHeadersEnv) {
      const parsed: Record<string, string> = {};
      for (const line of customHeadersEnv.split('\n')) {
        const colon = line.indexOf(':');
        if (colon >= 0) {
          parsed[line.substring(0, colon).trim()] = line.substring(colon + 1).trim();
        }
      }
      options.defaultHeaders = { ...parsed, ...options.defaultHeaders };
    }

    this._options = options;

    this.apiKey = apiKey;
    this.runwayVersion = runwayVersion;
  }

  /**
   * Create a new client instance re-using the same options given to the current client with optional overriding.
   */
  withOptions(options: Partial<ClientOptions>): this {
    const client = new (this.constructor as any as new (props: ClientOptions) => typeof this)({
      ...this._options,
      baseURL: this.baseURL,
      maxRetries: this.maxRetries,
      timeout: this.timeout,
      logger: this.logger,
      logLevel: this.logLevel,
      fetch: this.fetch,
      fetchOptions: this.fetchOptions,
      apiKey: this.apiKey,
      runwayVersion: this.runwayVersion,
      ...options,
    });
    return client;
  }

  /**
   * Check whether the base URL is set to its default.
   */
  #baseURLOverridden(): boolean {
    return this.baseURL !== 'https://api.dev.runwayml.com';
  }

  protected defaultQuery(): Record<string, string | undefined> | undefined {
    return this._options.defaultQuery;
  }

  protected validateHeaders({ values, nulls }: NullableHeaders) {
    return;
  }

  protected async authHeaders(opts: FinalRequestOptions): Promise<NullableHeaders | undefined> {
    return buildHeaders([{ Authorization: `Bearer ${this.apiKey}` }]);
  }

  /**
   * Basic re-implementation of `qs.stringify` for primitive types.
   */
  protected stringifyQuery(query: object | Record<string, unknown>): string {
    return stringifyQuery(query);
  }

  private getUserAgent(): string {
    return `${this.constructor.name}/JS ${VERSION}`;
  }

  protected defaultIdempotencyKey(): string {
    return `stainless-node-retry-${uuid4()}`;
  }

  protected makeStatusError(
    status: number,
    error: Object,
    message: string | undefined,
    headers: Headers,
  ): Errors.APIError {
    return Errors.APIError.generate(status, error, message, headers);
  }

  buildURL(
    path: string,
    query: Record<string, unknown> | null | undefined,
    defaultBaseURL?: string | undefined,
  ): string {
    const baseURL = (!this.#baseURLOverridden() && defaultBaseURL) || this.baseURL;
    const url =
      isAbsoluteURL(path) ?
        new URL(path)
      : new URL(baseURL + (baseURL.endsWith('/') && path.startsWith('/') ? path.slice(1) : path));

    const defaultQuery = this.defaultQuery();
    const pathQuery = Object.fromEntries(url.searchParams);
    if (!isEmptyObj(defaultQuery) || !isEmptyObj(pathQuery)) {
      query = { ...pathQuery, ...defaultQuery, ...query };
    }

    if (typeof query === 'object' && query && !Array.isArray(query)) {
      url.search = this.stringifyQuery(query);
    }

    return url.toString();
  }

  /**
   * Used as a callback for mutating the given `FinalRequestOptions` object.
   */
  protected async prepareOptions(options: FinalRequestOptions): Promise<void> {}

  /**
   * Used as a callback for mutating the given `RequestInit` object.
   *
   * This is useful for cases where you want to add certain headers based off of
   * the request properties, e.g. `method` or `url`.
   */
  protected async prepareRequest(
    request: RequestInit,
    { url, options }: { url: string; options: FinalRequestOptions },
  ): Promise<void> {}

  get<Rsp>(path: string, opts?: PromiseOrValue<RequestOptions>): APIPromise<Rsp> {
    return this.methodRequest('get', path, opts);
  }

  post<Rsp>(path: string, opts?: PromiseOrValue<RequestOptions>): APIPromise<Rsp> {
    return this.methodRequest('post', path, opts);
  }

  patch<Rsp>(path: string, opts?: PromiseOrValue<RequestOptions>): APIPromise<Rsp> {
    return this.methodRequest('patch', path, opts);
  }

  put<Rsp>(path: string, opts?: PromiseOrValue<RequestOptions>): APIPromise<Rsp> {
    return this.methodRequest('put', path, opts);
  }

  delete<Rsp>(path: string, opts?: PromiseOrValue<RequestOptions>): APIPromise<Rsp> {
    return this.methodRequest('delete', path, opts);
  }

  private methodRequest<Rsp>(
    method: HTTPMethod,
    path: string,
    opts?: PromiseOrValue<RequestOptions>,
  ): APIPromise<Rsp> {
    return this.request(
      Promise.resolve(opts).then((opts) => {
        return { method, path, ...opts };
      }),
    );
  }

  request<Rsp>(
    options: PromiseOrValue<FinalRequestOptions>,
    remainingRetries: number | null = null,
  ): APIPromise<Rsp> {
    return new APIPromise(this, this.makeRequest(options, remainingRetries, undefined));
  }

  private async makeRequest(
    optionsInput: PromiseOrValue<FinalRequestOptions>,
    retriesRemaining: number | null,
    retryOfRequestLogID: string | undefined,
  ): Promise<APIResponseProps> {
    const options = await optionsInput;
    const maxRetries = options.maxRetries ?? this.maxRetries;
    if (retriesRemaining == null) {
      retriesRemaining = maxRetries;
    }

    await this.prepareOptions(options);

    const { req, url, timeout } = await this.buildRequest(options, {
      retryCount: maxRetries - retriesRemaining,
    });

    await this.prepareRequest(req, { url, options });

    /** Not an API request ID, just for correlating local log entries. */
    const requestLogID = 'log_' + ((Math.random() * (1 << 24)) | 0).toString(16).padStart(6, '0');
    const retryLogStr = retryOfRequestLogID === undefined ? '' : `, retryOf: ${retryOfRequestLogID}`;
    const startTime = Date.now();

    loggerFor(this).debug(
      `[${requestLogID}] sending request`,
      formatRequestDetails({
        retryOfRequestLogID,
        method: options.method,
        url,
        options,
        headers: req.headers,
      }),
    );

    if (options.signal?.aborted) {
      throw new Errors.APIUserAbortError();
    }

    const controller = new AbortController();
    const response = await this.fetchWithTimeout(url, req, timeout, controller).catch(castToError);
    const headersTime = Date.now();

    if (response instanceof globalThis.Error) {
      const retryMessage = `retrying, ${retriesRemaining} attempts remaining`;
      if (options.signal?.aborted) {
        throw new Errors.APIUserAbortError();
      }
      // detect native connection timeout errors
      // deno throws "TypeError: error sending request for url (https://example/): client error (Connect): tcp connect error: Operation timed out (os error 60): Operation timed out (os error 60)"
      // undici throws "TypeError: fetch failed" with cause "ConnectTimeoutError: Connect Timeout Error (attempted address: example:443, timeout: 1ms)"
      // others do not provide enough information to distinguish timeouts from other connection errors
      const isTimeout =
        isAbortError(response) ||
        /timed? ?out/i.test(String(response) + ('cause' in response ? String(response.cause) : ''));
      if (retriesRemaining) {
        loggerFor(this).info(
          `[${requestLogID}] connection ${isTimeout ? 'timed out' : 'failed'} - ${retryMessage}`,
        );
        loggerFor(this).debug(
          `[${requestLogID}] connection ${isTimeout ? 'timed out' : 'failed'} (${retryMessage})`,
          formatRequestDetails({
            retryOfRequestLogID,
            url,
            durationMs: headersTime - startTime,
            message: response.message,
          }),
        );
        return this.retryRequest(options, retriesRemaining, retryOfRequestLogID ?? requestLogID);
      }
      loggerFor(this).info(
        `[${requestLogID}] connection ${isTimeout ? 'timed out' : 'failed'} - error; no more retries left`,
      );
      loggerFor(this).debug(
        `[${requestLogID}] connection ${isTimeout ? 'timed out' : 'failed'} (error; no more retries left)`,
        formatRequestDetails({
          retryOfRequestLogID,
          url,
          durationMs: headersTime - startTime,
          message: response.message,
        }),
      );
      if (isTimeout) {
        throw new Errors.APIConnectionTimeoutError();
      }
      throw new Errors.APIConnectionError({ cause: response });
    }

    const responseInfo = `[${requestLogID}${retryLogStr}] ${req.method} ${url} ${
      response.ok ? 'succeeded' : 'failed'
    } with status ${response.status} in ${headersTime - startTime}ms`;

    if (!response.ok) {
      const shouldRetry = await this.shouldRetry(response);
      if (retriesRemaining && shouldRetry) {
        const retryMessage = `retrying, ${retriesRemaining} attempts remaining`;

        // We don't need the body of this response.
        await Shims.CancelReadableStream(response.body);
        loggerFor(this).info(`${responseInfo} - ${retryMessage}`);
        loggerFor(this).debug(
          `[${requestLogID}] response error (${retryMessage})`,
          formatRequestDetails({
            retryOfRequestLogID,
            url: response.url,
            status: response.status,
            headers: response.headers,
            durationMs: headersTime - startTime,
          }),
        );
        return this.retryRequest(
          options,
          retriesRemaining,
          retryOfRequestLogID ?? requestLogID,
          response.headers,
        );
      }

      const retryMessage = shouldRetry ? `error; no more retries left` : `error; not retryable`;

      loggerFor(this).info(`${responseInfo} - ${retryMessage}`);

      const errText = await response.text().catch((err: any) => castToError(err).message);
      const errJSON = safeJSON(errText) as any;
      const errMessage = errJSON ? undefined : errText;

      loggerFor(this).debug(
        `[${requestLogID}] response error (${retryMessage})`,
        formatRequestDetails({
          retryOfRequestLogID,
          url: response.url,
          status: response.status,
          headers: response.headers,
          message: errMessage,
          durationMs: Date.now() - startTime,
        }),
      );

      const err = this.makeStatusError(response.status, errJSON, errMessage, response.headers);
      throw err;
    }

    loggerFor(this).info(responseInfo);
    loggerFor(this).debug(
      `[${requestLogID}] response start`,
      formatRequestDetails({
        retryOfRequestLogID,
        url: response.url,
        status: response.status,
        headers: response.headers,
        durationMs: headersTime - startTime,
      }),
    );

    return { response, options, controller, requestLogID, retryOfRequestLogID, startTime };
  }

  getAPIList<Item, PageClass extends Pagination.AbstractPage<Item> = Pagination.AbstractPage<Item>>(
    path: string,
    Page: new (...args: any[]) => PageClass,
    opts?: PromiseOrValue<RequestOptions>,
  ): Pagination.PagePromise<PageClass, Item> {
    return this.requestAPIList(
      Page,
      opts && 'then' in opts ?
        opts.then((opts) => ({ method: 'get', path, ...opts }))
      : { method: 'get', path, ...opts },
    );
  }

  requestAPIList<
    Item = unknown,
    PageClass extends Pagination.AbstractPage<Item> = Pagination.AbstractPage<Item>,
  >(
    Page: new (...args: ConstructorParameters<typeof Pagination.AbstractPage>) => PageClass,
    options: PromiseOrValue<FinalRequestOptions>,
  ): Pagination.PagePromise<PageClass, Item> {
    const request = this.makeRequest(options, null, undefined);
    return new Pagination.PagePromise<PageClass, Item>(this as any as RunwayML, request, Page);
  }

  async fetchWithTimeout(
    url: RequestInfo,
    init: RequestInit | undefined,
    ms: number,
    controller: AbortController,
  ): Promise<Response> {
    const { signal, method, ...options } = init || {};
    const abort = this._makeAbort(controller);
    if (signal) signal.addEventListener('abort', abort, { once: true });

    const timeout = setTimeout(abort, ms);

    const isReadableBody =
      ((globalThis as any).ReadableStream && options.body instanceof (globalThis as any).ReadableStream) ||
      (typeof options.body === 'object' && options.body !== null && Symbol.asyncIterator in options.body);

    const fetchOptions: RequestInit = {
      signal: controller.signal as any,
      ...(isReadableBody ? { duplex: 'half' } : {}),
      method: 'GET',
      ...options,
    };
    if (method) {
      // Custom methods like 'patch' need to be uppercased
      // See https://github.com/nodejs/undici/issues/2294
      fetchOptions.method = method.toUpperCase();
    }

    try {
      // use undefined this binding; fetch errors if bound to something else in browser/cloudflare
      return await this.fetch.call(undefined, url, fetchOptions);
    } finally {
      clearTimeout(timeout);
    }
  }

  private async shouldRetry(response: Response): Promise<boolean> {
    // Note this is not a standard header.
    const shouldRetryHeader = response.headers.get('x-should-retry');

    // If the server explicitly says whether or not to retry, obey.
    if (shouldRetryHeader === 'true') return true;
    if (shouldRetryHeader === 'false') return false;

    // Retry on request timeouts.
    if (response.status === 408) return true;

    // Retry on lock timeouts.
    if (response.status === 409) return true;

    // Retry on rate limits.
    if (response.status === 429) return true;

    // Retry internal errors.
    if (response.status >= 500) return true;

    return false;
  }

  private async retryRequest(
    options: FinalRequestOptions,
    retriesRemaining: number,
    requestLogID: string,
    responseHeaders?: Headers | undefined,
  ): Promise<APIResponseProps> {
    let timeoutMillis: number | undefined;

    // Note the `retry-after-ms` header may not be standard, but is a good idea and we'd like proactive support for it.
    const retryAfterMillisHeader = responseHeaders?.get('retry-after-ms');
    if (retryAfterMillisHeader) {
      const timeoutMs = parseFloat(retryAfterMillisHeader);
      if (!Number.isNaN(timeoutMs)) {
        timeoutMillis = timeoutMs;
      }
    }

    // About the Retry-After header: https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Retry-After
    const retryAfterHeader = responseHeaders?.get('retry-after');
    if (retryAfterHeader && !timeoutMillis) {
      const timeoutSeconds = parseFloat(retryAfterHeader);
      if (!Number.isNaN(timeoutSeconds)) {
        timeoutMillis = timeoutSeconds * 1000;
      } else {
        timeoutMillis = Date.parse(retryAfterHeader) - Date.now();
      }
    }

    // If the API asks us to wait a certain amount of time, just do what it
    // says, but otherwise calculate a default
    if (timeoutMillis === undefined) {
      const maxRetries = options.maxRetries ?? this.maxRetries;
      timeoutMillis = this.calculateDefaultRetryTimeoutMillis(retriesRemaining, maxRetries);
    }
    await sleep(timeoutMillis);

    return this.makeRequest(options, retriesRemaining - 1, requestLogID);
  }

  private calculateDefaultRetryTimeoutMillis(retriesRemaining: number, maxRetries: number): number {
    const initialRetryDelay = 0.5;
    const maxRetryDelay = 8.0;

    const numRetries = maxRetries - retriesRemaining;

    // Apply exponential backoff, but not more than the max.
    const sleepSeconds = Math.min(initialRetryDelay * Math.pow(2, numRetries), maxRetryDelay);

    // Apply some jitter, take up to at most 25 percent of the retry time.
    const jitter = 1 - Math.random() * 0.25;

    return sleepSeconds * jitter * 1000;
  }

  async buildRequest(
    inputOptions: FinalRequestOptions,
    { retryCount = 0 }: { retryCount?: number } = {},
  ): Promise<{ req: FinalizedRequestInit; url: string; timeout: number }> {
    const options = { ...inputOptions };
    const { method, path, query, defaultBaseURL } = options;

    const url = this.buildURL(path!, query as Record<string, unknown>, defaultBaseURL);
    if ('timeout' in options) validatePositiveInteger('timeout', options.timeout);
    options.timeout = options.timeout ?? this.timeout;
    const { bodyHeaders, body } = this.buildBody({ options });
    const reqHeaders = await this.buildHeaders({ options: inputOptions, method, bodyHeaders, retryCount });

    const req: FinalizedRequestInit = {
      method,
      headers: reqHeaders,
      ...(options.signal && { signal: options.signal }),
      ...((globalThis as any).ReadableStream &&
        body instanceof (globalThis as any).ReadableStream && { duplex: 'half' }),
      ...(body && { body }),
      ...((this.fetchOptions as any) ?? {}),
      ...((options.fetchOptions as any) ?? {}),
    };

    return { req, url, timeout: options.timeout };
  }

  private async buildHeaders({
    options,
    method,
    bodyHeaders,
    retryCount,
  }: {
    options: FinalRequestOptions;
    method: HTTPMethod;
    bodyHeaders: HeadersLike;
    retryCount: number;
  }): Promise<Headers> {
    let idempotencyHeaders: HeadersLike = {};
    if (this.idempotencyHeader && method !== 'get') {
      if (!options.idempotencyKey) options.idempotencyKey = this.defaultIdempotencyKey();
      idempotencyHeaders[this.idempotencyHeader] = options.idempotencyKey;
    }

    const headers = buildHeaders([
      idempotencyHeaders,
      {
        Accept: 'application/json',
        'User-Agent': this.getUserAgent(),
        'X-Stainless-Retry-Count': String(retryCount),
        ...(options.timeout ? { 'X-Stainless-Timeout': String(Math.trunc(options.timeout / 1000)) } : {}),
        ...getPlatformHeaders(),
        'X-Runway-Version': this.runwayVersion,
      },
      await this.authHeaders(options),
      this._options.defaultHeaders,
      bodyHeaders,
      options.headers,
    ]);

    this.validateHeaders(headers);

    return headers.values;
  }

  private _makeAbort(controller: AbortController) {
    // note: we can't just inline this method inside `fetchWithTimeout()` because then the closure
    //       would capture all request options, and cause a memory leak.
    return () => controller.abort();
  }

  private buildBody({ options }: { options: FinalRequestOptions }): {
    bodyHeaders: HeadersLike;
    body: BodyInit | undefined;
  } {
    const { body, headers: rawHeaders } = options;
    if (!body) {
      // A resource method always passes a `body` key when its operation defines a
      // request body, even if the caller omitted an optional body param. Keep the
      // content-type for those, and only elide it for operations with no body at
      // all (e.g. GET/DELETE).
      if (body == null && 'body' in options) {
        return this.#encoder({ body, headers: buildHeaders([rawHeaders]) });
      }
      return { bodyHeaders: undefined, body: undefined };
    }
    const headers = buildHeaders([rawHeaders]);
    if (
      // Pass raw type verbatim
      ArrayBuffer.isView(body) ||
      body instanceof ArrayBuffer ||
      body instanceof DataView ||
      (typeof body === 'string' &&
        // Preserve legacy string encoding behavior for now
        headers.values.has('content-type')) ||
      // `Blob` is superset of `File`
      ((globalThis as any).Blob && body instanceof (globalThis as any).Blob) ||
      // `FormData` -> `multipart/form-data`
      body instanceof FormData ||
      // `URLSearchParams` -> `application/x-www-form-urlencoded`
      body instanceof URLSearchParams ||
      // Send chunked stream (each chunk has own `length`)
      ((globalThis as any).ReadableStream && body instanceof (globalThis as any).ReadableStream)
    ) {
      return { bodyHeaders: undefined, body: body as BodyInit };
    } else if (
      typeof body === 'object' &&
      (Symbol.asyncIterator in body ||
        (Symbol.iterator in body && 'next' in body && typeof body.next === 'function'))
    ) {
      return { bodyHeaders: undefined, body: Shims.ReadableStreamFrom(body as AsyncIterable<Uint8Array>) };
    } else if (
      typeof body === 'object' &&
      headers.values.get('content-type') === 'application/x-www-form-urlencoded'
    ) {
      return {
        bodyHeaders: { 'content-type': 'application/x-www-form-urlencoded' },
        body: this.stringifyQuery(body),
      };
    } else {
      return this.#encoder({ body, headers });
    }
  }

  static RunwayML = this;
  static DEFAULT_TIMEOUT = 60000; // 1 minute

  static RunwayMLError = Errors.RunwayMLError;
  static APIError = Errors.APIError;
  static APIConnectionError = Errors.APIConnectionError;
  static APIConnectionTimeoutError = Errors.APIConnectionTimeoutError;
  static APIUserAbortError = Errors.APIUserAbortError;
  static NotFoundError = Errors.NotFoundError;
  static ConflictError = Errors.ConflictError;
  static RateLimitError = Errors.RateLimitError;
  static BadRequestError = Errors.BadRequestError;
  static AuthenticationError = Errors.AuthenticationError;
  static InternalServerError = Errors.InternalServerError;
  static PermissionDeniedError = Errors.PermissionDeniedError;
  static UnprocessableEntityError = Errors.UnprocessableEntityError;

  static toFile = UploadsCore.toFile;

  /**
   * Endpoints for managing tasks that have been submitted.
   */
  tasks: API.Tasks = new API.Tasks(this);
  /**
   * These endpoints all kick off tasks to create generations.
   */
  imageToVideo: API.ImageToVideo = new API.ImageToVideo(this);
  /**
   * These endpoints all kick off tasks to create generations.
   */
  videoToVideo: API.VideoToVideo = new API.VideoToVideo(this);
  /**
   * These endpoints all kick off tasks to create generations.
   */
  textToVideo: API.TextToVideo = new API.TextToVideo(this);
  /**
   * These endpoints all kick off tasks to create generations.
   */
  textToImage: API.TextToImage = new API.TextToImage(this);
  /**
   * These endpoints all kick off tasks to create generations.
   */
  characterPerformance: API.CharacterPerformance = new API.CharacterPerformance(this);
  /**
   * These endpoints all kick off tasks to create generations.
   */
  textToSpeech: API.TextToSpeech = new API.TextToSpeech(this);
  /**
   * These endpoints all kick off tasks to create generations.
   */
  soundEffect: API.SoundEffect = new API.SoundEffect(this);
  /**
   * These endpoints all kick off tasks to create generations.
   */
  voiceIsolation: API.VoiceIsolation = new API.VoiceIsolation(this);
  /**
   * These endpoints all kick off tasks to create generations.
   */
  voiceDubbing: API.VoiceDubbing = new API.VoiceDubbing(this);
  /**
   * These endpoints all kick off tasks to create generations.
   */
  speechToSpeech: API.SpeechToSpeech = new API.SpeechToSpeech(this);
  /**
   * These endpoints all kick off tasks to create generations.
   */
  imageUpscale: API.ImageUpscale = new API.ImageUpscale(this);
  organization: API.Organization = new API.Organization(this);
  avatars: API.Avatars = new API.Avatars(this);
  avatarConversations: API.AvatarConversations = new API.AvatarConversations(this);
  avatarVideos: API.AvatarVideos = new API.AvatarVideos(this);
  documents: API.Documents = new API.Documents(this);
  realtimeSessions: API.RealtimeSessions = new API.RealtimeSessions(this);
  recipes: API.Recipes = new API.Recipes(this);
  voices: API.Voices = new API.Voices(this);
  uploads: API.Uploads = new API.Uploads(this);
  workflows: API.Workflows = new API.Workflows(this);
  workflowInvocations: API.WorkflowInvocations = new API.WorkflowInvocations(this);
}

RunwayML.Tasks = Tasks;
RunwayML.ImageToVideo = ImageToVideo;
RunwayML.VideoToVideo = VideoToVideo;
RunwayML.TextToVideo = TextToVideo;
RunwayML.TextToImage = TextToImage;
RunwayML.CharacterPerformance = CharacterPerformance;
RunwayML.TextToSpeech = TextToSpeech;
RunwayML.SoundEffect = SoundEffect;
RunwayML.VoiceIsolation = VoiceIsolation;
RunwayML.VoiceDubbing = VoiceDubbing;
RunwayML.SpeechToSpeech = SpeechToSpeech;
RunwayML.ImageUpscale = ImageUpscale;
RunwayML.Organization = Organization;
RunwayML.Avatars = Avatars;
RunwayML.AvatarConversations = AvatarConversations;
RunwayML.AvatarVideos = AvatarVideos;
RunwayML.Documents = Documents;
RunwayML.RealtimeSessions = RealtimeSessions;
RunwayML.Recipes = Recipes;
RunwayML.Voices = Voices;
RunwayML.Uploads = Uploads;
RunwayML.Workflows = Workflows;
RunwayML.WorkflowInvocations = WorkflowInvocations;

export declare namespace RunwayML {
  export type RequestOptions = Opts.RequestOptions;

  export import CursorPage = Pagination.CursorPage;
  export { type CursorPageParams as CursorPageParams, type CursorPageResponse as CursorPageResponse };

  export { Tasks as Tasks, type TaskRetrieveResponse as TaskRetrieveResponse };

  export {
    ImageToVideo as ImageToVideo,
    type ImageToVideoCreateResponse as ImageToVideoCreateResponse,
    type ImageToVideoCreateParams as ImageToVideoCreateParams,
  };

  export {
    VideoToVideo as VideoToVideo,
    type VideoToVideoCreateResponse as VideoToVideoCreateResponse,
    type VideoToVideoCreateParams as VideoToVideoCreateParams,
  };

  export {
    TextToVideo as TextToVideo,
    type TextToVideoCreateResponse as TextToVideoCreateResponse,
    type TextToVideoCreateParams as TextToVideoCreateParams,
  };

  export {
    TextToImage as TextToImage,
    type TextToImageCreateResponse as TextToImageCreateResponse,
    type TextToImageCreateParams as TextToImageCreateParams,
  };

  export {
    CharacterPerformance as CharacterPerformance,
    type CharacterPerformanceCreateResponse as CharacterPerformanceCreateResponse,
    type CharacterPerformanceCreateParams as CharacterPerformanceCreateParams,
  };

  export {
    TextToSpeech as TextToSpeech,
    type TextToSpeechCreateResponse as TextToSpeechCreateResponse,
    type TextToSpeechCreateParams as TextToSpeechCreateParams,
  };

  export {
    SoundEffect as SoundEffect,
    type SoundEffectCreateResponse as SoundEffectCreateResponse,
    type SoundEffectCreateParams as SoundEffectCreateParams,
  };

  export {
    VoiceIsolation as VoiceIsolation,
    type VoiceIsolationCreateResponse as VoiceIsolationCreateResponse,
    type VoiceIsolationCreateParams as VoiceIsolationCreateParams,
  };

  export {
    VoiceDubbing as VoiceDubbing,
    type VoiceDubbingCreateResponse as VoiceDubbingCreateResponse,
    type VoiceDubbingCreateParams as VoiceDubbingCreateParams,
  };

  export {
    SpeechToSpeech as SpeechToSpeech,
    type SpeechToSpeechCreateResponse as SpeechToSpeechCreateResponse,
    type SpeechToSpeechCreateParams as SpeechToSpeechCreateParams,
  };

  export {
    ImageUpscale as ImageUpscale,
    type ImageUpscaleCreateResponse as ImageUpscaleCreateResponse,
    type ImageUpscaleCreateParams as ImageUpscaleCreateParams,
  };

  export {
    Organization as Organization,
    type OrganizationRetrieveResponse as OrganizationRetrieveResponse,
    type OrganizationRetrieveUsageResponse as OrganizationRetrieveUsageResponse,
    type OrganizationRetrieveUsageParams as OrganizationRetrieveUsageParams,
  };

  export {
    Avatars as Avatars,
    type AvatarCreateResponse as AvatarCreateResponse,
    type AvatarRetrieveResponse as AvatarRetrieveResponse,
    type AvatarUpdateResponse as AvatarUpdateResponse,
    type AvatarListResponse as AvatarListResponse,
    type AvatarGetUsageResponse as AvatarGetUsageResponse,
    type AvatarListResponsesCursorPage as AvatarListResponsesCursorPage,
    type AvatarCreateParams as AvatarCreateParams,
    type AvatarUpdateParams as AvatarUpdateParams,
    type AvatarListParams as AvatarListParams,
    type AvatarGetUsageParams as AvatarGetUsageParams,
  };

  export {
    AvatarConversations as AvatarConversations,
    type AvatarConversationRetrieveResponse as AvatarConversationRetrieveResponse,
    type AvatarConversationListResponse as AvatarConversationListResponse,
    type AvatarConversationListResponsesCursorPage as AvatarConversationListResponsesCursorPage,
    type AvatarConversationListParams as AvatarConversationListParams,
  };

  export {
    AvatarVideos as AvatarVideos,
    type AvatarVideoCreateResponse as AvatarVideoCreateResponse,
    type AvatarVideoCreateParams as AvatarVideoCreateParams,
  };

  export {
    Documents as Documents,
    type DocumentCreateResponse as DocumentCreateResponse,
    type DocumentRetrieveResponse as DocumentRetrieveResponse,
    type DocumentListResponse as DocumentListResponse,
    type DocumentListResponsesCursorPage as DocumentListResponsesCursorPage,
    type DocumentCreateParams as DocumentCreateParams,
    type DocumentUpdateParams as DocumentUpdateParams,
    type DocumentListParams as DocumentListParams,
  };

  export {
    RealtimeSessions as RealtimeSessions,
    type RealtimeSessionCreateResponse as RealtimeSessionCreateResponse,
    type RealtimeSessionRetrieveResponse as RealtimeSessionRetrieveResponse,
    type RealtimeSessionCreateParams as RealtimeSessionCreateParams,
  };

  export {
    Recipes as Recipes,
    type RecipeMarketingStockImageResponse as RecipeMarketingStockImageResponse,
    type RecipeMultiShotVideoResponse as RecipeMultiShotVideoResponse,
    type RecipeProductAdResponse as RecipeProductAdResponse,
    type RecipeProductCampaignImageResponse as RecipeProductCampaignImageResponse,
    type RecipeProductSwapResponse as RecipeProductSwapResponse,
    type RecipeProductUgcResponse as RecipeProductUgcResponse,
    type RecipeMarketingStockImageParams as RecipeMarketingStockImageParams,
    type RecipeMultiShotVideoParams as RecipeMultiShotVideoParams,
    type RecipeProductAdParams as RecipeProductAdParams,
    type RecipeProductCampaignImageParams as RecipeProductCampaignImageParams,
    type RecipeProductSwapParams as RecipeProductSwapParams,
    type RecipeProductUgcParams as RecipeProductUgcParams,
  };

  export {
    Voices as Voices,
    type VoiceCreateResponse as VoiceCreateResponse,
    type VoiceRetrieveResponse as VoiceRetrieveResponse,
    type VoiceUpdateResponse as VoiceUpdateResponse,
    type VoiceListResponse as VoiceListResponse,
    type VoicePreviewResponse as VoicePreviewResponse,
    type VoiceListResponsesCursorPage as VoiceListResponsesCursorPage,
    type VoiceCreateParams as VoiceCreateParams,
    type VoiceUpdateParams as VoiceUpdateParams,
    type VoiceListParams as VoiceListParams,
    type VoicePreviewParams as VoicePreviewParams,
  };

  export {
    Uploads as Uploads,
    type UploadCreateEphemeralResponse as UploadCreateEphemeralResponse,
    type UploadsCreateEphemeralParams as UploadsCreateEphemeralParams,
  };

  export {
    Workflows as Workflows,
    type WorkflowRetrieveResponse as WorkflowRetrieveResponse,
    type WorkflowListResponse as WorkflowListResponse,
    type WorkflowRunResponse as WorkflowRunResponse,
    type WorkflowRunParams as WorkflowRunParams,
  };

  export {
    WorkflowInvocations as WorkflowInvocations,
    type WorkflowInvocationRetrieveResponse as WorkflowInvocationRetrieveResponse,
  };
}
