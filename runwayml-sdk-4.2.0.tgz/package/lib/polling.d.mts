import type { RunwayML } from "../client.mjs";
import { APIPromise } from "../core/api-promise.mjs";
import { TaskRetrieveResponse } from "../resources/tasks.mjs";
import { WorkflowInvocationRetrieveResponse } from "../resources/workflow-invocations.mjs";
export declare class TaskFailedError extends Error {
    taskDetails: TaskRetrieveResponse;
    constructor(taskDetails: TaskRetrieveResponse.Failed | TaskRetrieveResponse.Cancelled);
}
export declare class TaskTimedOutError extends Error {
    taskDetails: TaskRetrieveResponse;
    constructor(taskDetails: TaskRetrieveResponse);
}
export interface WaitForTaskOutputOptions {
    /**
     * The maximum amount of time to wait for the task to complete in milliseconds. If not
     * specified, the default timeout is 10 minutes. Will raise a `TaskTimeoutError` if the
     * task does not complete within the timeout. Setting this to `null` will wait
     * indefinitely (disabling the timeout). Disabling the timeout is not recommended.
     * as it may cause your server to experience issues if your Runway API organization
     * reaches its concurrency limit or if Runway experiences an outage.
     */
    timeout?: number | null;
    /**
     * Passing an `AbortSignal` allows you to stop waiting for the task to complete.
     * If you are using `waitForTaskOutput` in the handler for an incoming request,
     * `waitForTaskOutput` will not stop polling if the client connection is closed.
     * Passing an `AbortSignal` safely stops polling, preventing memory leaks and
     * ensuring you do not create too many requests to the Runway API.
     */
    abortSignal?: AbortSignal;
}
export declare class AbortError extends Error {
    code: number;
    constructor();
}
export declare class WorkflowInvocationFailedError extends Error {
    invocationDetails: WorkflowInvocationRetrieveResponse;
    constructor(invocationDetails: WorkflowInvocationRetrieveResponse.Failed | WorkflowInvocationRetrieveResponse.Cancelled);
}
export declare class WorkflowInvocationTimedOutError extends Error {
    invocationDetails: WorkflowInvocationRetrieveResponse;
    constructor(invocationDetails: WorkflowInvocationRetrieveResponse);
}
export type APIPromiseWithAwaitableTask<T extends {
    id: string;
}> = APIPromise<T> & {
    /**
     * When called, this will wait until the task is complete.
     *
     * If the task fails or is cancelled, a `TaskFailedError` will be thrown.
     */
    waitForTaskOutput: (options?: WaitForTaskOutputOptions) => Promise<TaskRetrieveResponse.Succeeded>;
};
export declare function wrapAsWaitableResource<T extends {
    id: string;
}>(client: RunwayML): (responsePromise: APIPromise<T>, skipInitialWait?: boolean) => APIPromiseWithAwaitableTask<T>;
export type APIPromiseWithAwaitableWorkflowInvocation<T extends {
    id: string;
}> = APIPromise<T> & {
    /**
     * When called, this will wait until the workflow invocation is complete.
     *
     * If the invocation fails or is cancelled, a `WorkflowInvocationFailedError` will be thrown.
     */
    waitForTaskOutput: (options?: WaitForTaskOutputOptions) => Promise<WorkflowInvocationRetrieveResponse.Succeeded>;
};
export declare function wrapAsWaitableWorkflowInvocation<T extends {
    id: string;
}>(client: RunwayML): (responsePromise: APIPromise<T>, skipInitialWait?: boolean) => APIPromiseWithAwaitableWorkflowInvocation<T>;
//# sourceMappingURL=polling.d.mts.map